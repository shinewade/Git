package besLib.cal;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import xoc.dta.datatypes.MultiSiteLong;
import xoc.dta.datatypes.MultiSiteLongArray;
import xoc.dta.datatypes.MultiSitePatternFailureList;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDigInOutCallPassFailResults;
import xoc.dta.resultaccess.IDigInOutCyclePassFailResults;
import xoc.dta.resultaccess.IDigInOutResults;
import xoc.dta.setupaccess.IPatternCall;
import xoc.dta.testdescriptor.IFunctionalTestDescriptor;
import xoc.dta.workspace.IWorkspace;

public final class BesCalc_DFT{
    IMeasurement imeasurement;
    IFunctionalTestDescriptor ifunctionalTestDescriptor;
    IDigInOutResults digInOutResults;
    String capturePinName;


    /**
     * Constructor function
     * @param imeasurement This interface enables you to read and write to the measurement object
     * @param IFunctionalTestDescriptor This interface provides access to the test descriptor used with functional tests
     * @param capturePinName Captured pin name in pattern
     *
     */
    public BesCalc_DFT(IMeasurement imeasurement, IFunctionalTestDescriptor ifunctionalTestDescriptor, String capturePinName) {
        this.imeasurement=imeasurement;
        this.ifunctionalTestDescriptor=ifunctionalTestDescriptor;
        this.capturePinName=capturePinName;
        this.digInOutResults = imeasurement.digInOut(capturePinName).preserveResults(ifunctionalTestDescriptor);
    }

    /**
     * Get last executed measurement overall result
     * @return Overall pass/fail result in MultiSiteLong type
     */
    public MultiSiteLong getOverallResult() {
        MultiSiteLong patRes=new MultiSiteLong(0);
        for(int site:this.digInOutResults.hasPassed().getActiveSites()) {
            if(this.digInOutResults.hasPassed().get(site)==true) {
                patRes.set(site,1);
            }
        }
        return patRes;
    }

    /**
     * Get last executed measurement overall result
     * @return Overall pass/fail result in multiSiteBoolean type
     */
    public MultiSiteLongArray getIndividualResult() {
        IDigInOutCallPassFailResults callPassFailResults=this.imeasurement.digInOut(this.capturePinName).preserveCallPassFailResults();
        MultiSiteLongArray patRes=new MultiSiteLongArray(callPassFailResults.getPatternPassFail().length, 0);
        for(int i=0;i<callPassFailResults.getPatternPassFail().length;i++) {
            for(int site:callPassFailResults.getPatternPassFail()[0].hasPassed().getActiveSites()) {
                if(callPassFailResults.getPatternPassFail()[i].hasPassed().get(site)==true) {
                    patRes.setElement(site, i, 1);
                }
            }

            System.out.println("PatCall= "+callPassFailResults.getPatternPassFail()[i].getPatternCall());
            System.out.println("PatCal Result= "+callPassFailResults.getPatternPassFail()[i].hasPassed());
            System.out.println();
        }
        return patRes;
    }


    /**
     * Pattern fail cycle write to text.
     * @param failCycles Pattern fail cycles saved to text
     * @return Null
     */
    @SuppressWarnings("null")
    public void writeFailLog2Text(int failCycles)
    {
        IDigInOutCyclePassFailResults cyclePassFailResults = imeasurement.digInOut(capturePinName).preserveCyclePassFailResults();
        //get pattern name from operating sequencer
        List<IPatternCall> patternCall=this.digInOutResults.getPatternCalls();

        //get pattern failure per pattern
        @SuppressWarnings("unchecked")
        Map<String, MultiSitePatternFailureList>[] failLog=new Map[patternCall.size()];
        String[] patName=new String[patternCall.size()];
        for(int patindex=0; patindex<patternCall.size(); patindex++) {
            failLog[patindex] = cyclePassFailResults.pattern(patternCall.get(patindex)).getPatternFailures();
            patName[patindex]=patternCall.get(patindex).toString().substring( patternCall.get(patindex).toString().lastIndexOf(".")+1 ).replace(";", "");
        }

        //get pattern failure information
        for(int patindex=0; patindex<patternCall.size(); patindex++) {
            for(String Pin:failLog[patindex].keySet()) {
                int activeSites[]=failLog[patindex].get(Pin).getActiveSites();
                for(int site:activeSites) {
                    SimpleDateFormat df=new SimpleDateFormat("yyyyMMdd_HHmmss");

                    //Write fail log to text
                    if(failLog[patindex].get(Pin).get(site).size()!=0) {
                        @SuppressWarnings("resource")
                        BufferedWriter bw=null;
                        try
                        {
                            System.out.println(IWorkspace.getActiveProjectPath());
                            bw=new BufferedWriter(new FileWriter(IWorkspace.getActiveProjectPath()+"/"+"Time_"+df.format(new Date())+"__"+patName[patindex]+"_"+"PatCall"+patindex+"_site"+site+".txt",true));//"/export/home/bestechnic3/BT1501"
                            bw.write("*********************************************************************************************************************");
                            bw.newLine();
                            for(int i=0;i<patName.length;i++) {
                                bw.write(patName[i]);
                                bw.newLine();
                            }
                            bw.write("*********************************************************************************************************************");
                            bw.newLine();
                            bw.flush();
                            bw.write("site["+site+"] "+Pin+" failcycle count: "+failLog[patindex].get(Pin).get(site).size());
                            bw.newLine();
                            bw.write("*********************************************************************************************************************");
                            bw.newLine();

                            bw.flush();
                            long maxFailCycles=0;
                            if(failLog[patindex].get(Pin).get(site).size()>failCycles) {
                                maxFailCycles=failCycles;
                            }
                            else {
                                maxFailCycles=failLog[patindex].get(Pin).get(site).size();
                            }
                            for(int failIndex=0; failIndex<maxFailCycles; failIndex++) {
    //                            System.out.println(""+failLog[patindex].get(Pin).get(site).get(failIndex));
                                bw.write(failLog[patindex].get(Pin).get(site).get(failIndex).toString());
                                bw.newLine();
                                bw.flush();
                            }
                            bw.newLine();
                            bw.newLine();
                            bw.newLine();
                            bw.newLine();
                            bw.newLine();
                            bw.newLine();
                            bw.flush();
                        }
                        catch (Exception e) {
                            // TODO: handle exception
                        }
                        finally{
                            try{
                               bw.close();
                            }
                            catch (Exception e2) {
                                // TODO: handle exception
                            }
                        }
                    }
                }
            }
        }



        System.out.println();
    }

}
