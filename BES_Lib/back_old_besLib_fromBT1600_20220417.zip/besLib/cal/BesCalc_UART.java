package besLib.cal;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;

import xoc.dta.datatypes.MultiSiteLong;
import xoc.dta.datatypes.MultiSiteLongArray;
import xoc.dta.datatypes.dsp.EdgeType;
import xoc.dta.datatypes.dsp.MultiSiteWaveLong;
import xoc.dta.datatypes.dsp.SearchDirection;
import xoc.dta.workspace.IWorkspace;

/**
 * This class is used for UART data process
 * @version V1.0
 * @author Ronnie Li, Weng Yongxin
 **/
public class BesCalc_UART {
    /**
     * Parse BES UART ASCII data and print <br>
     * BES UART Output format: <br>
     * <pre>
     * _______     ____________________________     ____________
     *        \___/ X   X   X   X   X   X   X  \___/
     * idle   start                              0   stop  idle
     * state  bit                                    bit   state
     *             LSB                          MSB</pre>
     * @param rawData digital capture data.
     * @param captureEdge XMode set in capture pin WaveTable, range: 1-6
     */
    public static void printRamRunOutput_ASCIIToConsole(MultiSiteWaveLong rawData,int captureEdge) {
        MultiSiteLongArray outputData=new BesCalc_UART().getRamrunData(rawData, captureEdge);
        for(int site: rawData.getActiveSites()) {
            System.out.println();
            System.out.println("****** RamRun Log "+"site="+site+" ******");
            System.out.println(BesCalc_General.asciiToString(outputData.get(site)));
            System.out.println("*******************************");
            System.out.println();
        }
    }


    /**
     * Parse BES UART ASCII data and save to text <br>
     * BES UART Output format: <br>
     * <pre>
     * _______     ____________________________     ____________
     *        \___/ X   X   X   X   X   X   X  \___/
     * idle   start                              0   stop  idle
     * state  bit                                    bit   state
     *             LSB                          MSB</pre>
     * @param rawData Digital capture data.
     * @param captureEdge XMode set in capture pin WaveTable, range: 1-6
     * @param fileName File name to be saved and only alphanumeric characters can be contained.
     */
    @SuppressWarnings({ "null", "resource" })
    public static void printRamRunOutput_ASCIIToTextFile(MultiSiteWaveLong rawData,int captureEdge, String fileName)
    {
        MultiSiteLongArray outputData=new BesCalc_UART().getRamrunData(rawData, captureEdge);
        String outputString[]=new String[rawData.getActiveSites().length];
        int siteIndex=0;
        for(int site: rawData.getActiveSites()) {
            outputString[siteIndex]=BesCalc_General.asciiToString(outputData.get(site));
            siteIndex++;
        }

        java.util.Date time = new java.util.Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
        BufferedWriter bw=null;
        siteIndex=0;
        try{
            bw=new BufferedWriter(new FileWriter(IWorkspace.getActiveProjectPath()+"/"+fileName.replace(" ", "_").replace(".", "")+".txt",true));
            System.out.println("RamRun UART output has Been generated in the path : "+IWorkspace.getActiveProjectPath()+"/"+fileName.replace(" ", "_").replace(".", "")+"_ASCII.txt");
            bw.write("****************************************************************");
            bw.newLine();
            bw.write(fileName+" -- System Time: "+sdf.format(time).toString());
            bw.newLine();
            bw.write("****************************************************************");
            bw.newLine();
            bw.flush();
            for(int site:rawData.getActiveSites()){
                if(!outputString[siteIndex].isEmpty()){
                    bw.write("site["+site+"]: ");
                    bw.newLine();
                    bw.flush();
                    bw.write(outputString[siteIndex]);
                    bw.newLine();
                    bw.newLine();
                    bw.newLine();
                    bw.newLine();
                    bw.newLine();
                    bw.newLine();
                    bw.flush();
                }
                siteIndex++;
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally{
            try{
                 bw.close();
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
    }

    /**
     * Parse BES UART Hex data and save to text <br>
     * BES UART Output format: <br>
     * <pre>
     * _______     ____________________________     ____________
     *        \___/ X   X   X   X   X   X   X  \___/
     * idle   start                              0   stop  idle
     * state  bit                                    bit   state
     *             LSB                          MSB</pre>
     * @param rawData digital capture data.
     * @param captureEdge XMode set in capture pin WaveTable, range: 1-6
     */
    @SuppressWarnings({ "null", "resource" })
    @Deprecated
    public static void printRamRunOutput_HexToTextFile(MultiSiteWaveLong rawData,int captureEdge, String fileName)
    {
        MultiSiteLongArray outputData=new BesCalc_UART().getRamrunData(rawData, captureEdge);

        java.util.Date time = new java.util.Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
        BufferedWriter bw=null;
        try
        {
            bw=new BufferedWriter(new FileWriter(IWorkspace.getActiveProjectPath()+"/hex_"+fileName.replace(" ", "_").replace(".", "")+".txt",true));
            System.out.println("RamRun UART output has Been generated in the path : "+IWorkspace.getActiveProjectPath()+"/hex_"+fileName.replace(" ", "_").replace(".", "")+".txt");
            bw.write("****************************************************************");
            bw.newLine();
            bw.write(fileName+" -- System Time: "+sdf.format(time).toString());
            bw.newLine();
            bw.write("Ramrun Debug Hex Data Log");
            bw.newLine();
            bw.write("****************************************************************");
            bw.newLine();
            bw.flush();
            for(int site:rawData.getActiveSites()){
                if(outputData.toMultiSiteWave().getSize(site)>0){
                    bw.write("site["+site+"]: ");
                    bw.newLine();
                    bw.flush();
                    for(int index=0;index<outputData.toMultiSiteWave().getSize(site);index++){
                        bw.write(Long.toHexString(outputData.getElement(site, index)));
                        bw.write(" ");
                        if(index%50==0){
                            bw.newLine();
                        }
                        bw.flush();
                        }
                    bw.newLine();
                    bw.flush();
                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally{
            try{
                 bw.close();
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
    }



    /**
     * Parse BES UART output data <br>
     * BES UART Output format: <br>
     * <pre>
     * _______     ____________________________     ____________
     *        \___/ X   X   X   X   X   X   X  \___/
     * idle   start                              0   stop  idle
     * state  bit                                    bit   state
     *             LSB                          MSB</pre>
     * @param rawData digital capture data.
     * @param captureEdge XMode set in capture pin WaveTable, range: 1-6
     * @return UART output data in ASCII format.
     */
    private MultiSiteLongArray getRamrunData(MultiSiteWaveLong rawData,int captureEdge) {
        int activeSite[]=rawData.getActiveSites();
        //back up rawData
        MultiSiteWaveLong rawData_Copy=new MultiSiteWaveLong();
        rawData_Copy.set(rawData);
        //set limiting condition
        if(captureEdge<1 || captureEdge >6) {
            new Exception("Error, XMode out of range 1-6 !!! ").printStackTrace();
        }
        //generate match pattern
        long[] startPatternArray = {1,1,1,1,1,1,1,1,0};  //9 bits, Left -> Right
        long[] stopPatternArray  = {0,1,1,1,1,1,1,1,1};  //9 bits, Left -> Right
        int startPatternArraySize=startPatternArray.length;
        long startPattern=0L;   //64 bits
        long stopPattern=0L;    //64 bits
        int startStopBitMatchCount=(int)(captureEdge*(2.0/3.0));
        int startStopBitIgnoreCount=(int)(captureEdge*(1.0/3.0));
        for(int i=0;i<startPatternArraySize;i++) {
            for(int j=0;j<captureEdge;j++) {
                //startPattern
                if( i==(startPatternArraySize-1) && j<startStopBitMatchCount ) {
                    startPattern=startPattern + (startPatternArray[i] << (captureEdge*(startPatternArraySize-1-i)+startStopBitMatchCount-1-j));
                }
                else {
                    startPattern=startPattern + (startPatternArray[i] << ( captureEdge*(startPatternArraySize-1-i)+startStopBitMatchCount-1-j));
                }
                //stopPattern
                if(i!=0) {
                    stopPattern=stopPattern + (stopPatternArray[i] << ( captureEdge*(startPatternArraySize-i)-j-1) );
                }
            }
        }
        //match pattern
        MultiSiteLongArray startPatIndices=rawData.searchSerial(startPattern, (startPatternArraySize-1)*captureEdge+startStopBitMatchCount, 0, SearchDirection.ASCENDING);
        MultiSiteLongArray stopPatIndices=rawData.searchSerial(stopPattern, (startPatternArraySize-1)*captureEdge+startStopBitMatchCount, 0, SearchDirection.ASCENDING);
        //match index size
        MultiSiteLong matchSize_StartPat=new MultiSiteLong();
        MultiSiteLong matchSize_StopPat=new MultiSiteLong();
        for(int site:activeSite) {
            matchSize_StartPat.set(site, startPatIndices.get(site).length);
            matchSize_StopPat.set(site, stopPatIndices.get(site).length);
        }
//        System.out.println("startPatIndices= "+startPatIndices);
//        System.out.println("stopPatIndices= "+stopPatIndices);
//        System.out.println("matchSize_StartPat= "+matchSize_StartPat);
//        System.out.println("matchSize_StopPat= "+matchSize_StopPat);

        //Raw data reduction, 16 bits per UART output (8 idle bits + 1 start bit(match 2/3*captureEdge times) + 8 data bit +1 stop bit(match 2/3*captureEdge times))
        for(int site:activeSite) {
            if(matchSize_StartPat.get(site) != matchSize_StopPat.get(site)) {
                if(matchSize_StartPat.get(site) < matchSize_StopPat.get(site)) {
                    matchSize_StopPat.set(site, matchSize_StartPat.get(site));
                    System.out.println("site= "+site);
                    System.out.println("Raw Data Captured by PS1600 abnormal, matchSize_StartPat < matchSize_StopPat in one site, pattern of searchSerial() need to be adjust !!! ");
                    System.out.println("it can be caused by strit match pattern in function searchSerial() or other possible reasons");
                }
                else {
                    matchSize_StartPat.set(site, matchSize_StopPat.get(site));
                    System.out.println("site= "+site);
                    System.out.println("Raw Data Captured by PS1600 abnormal,matchSize_StartPat > matchSize_StopPat in one site !!! ");
                    System.out.println("it can be caused by:");
                    System.out.println("1. Match pattern in function searchSerial() is strict");
                    System.out.println("2. UART output data does not be captured completely");
                    System.out.println("3. Other possible reasons ...");
                }
            }
//            else
            {
                int removeIndex_Start=0;
                int removeIndex_Stop=0;
                int removeIndex_Length=0;
                //remove idle bits after the last stop bit
                removeIndex_Start=(int) (stopPatIndices.getElement(site,matchSize_StopPat.get(site).intValue()-1)+captureEdge*2-startStopBitIgnoreCount);//after current stop bit
                removeIndex_Length =rawData.getSize(site)-removeIndex_Start;
                rawData.set(site, rawData.get(site).removeValues(removeIndex_Start,removeIndex_Length));
                //remove idle bits after first stop bit
                for(long i=matchSize_StartPat.get(site)-2; i>=0; i--) {
                    removeIndex_Start=(int) (stopPatIndices.getElement(site,(int)i ) + captureEdge*2-startStopBitIgnoreCount);//priors to current stop  bit
                    removeIndex_Stop =(int) (startPatIndices.getElement(site,(int)(i+1))+7*captureEdge );//next start bit
                    if( (removeIndex_Stop-removeIndex_Start)>1) {
                        removeIndex_Length=removeIndex_Stop-removeIndex_Start;
                        rawData.set(site, rawData.get(site).removeValues(removeIndex_Start,removeIndex_Length ));
                    }
                    else {
                        System.out.println("site= "+site);
                        System.out.println("(removeIndex_Stop - removeIndex_Start) <= 1 !!! ");
                        System.out.println("it can be caused by:");
                        System.out.println("1. MisMacth between function parameter \"captureEdge\" and actual digital capture pin recieve edge setted in timing spec file ");
                        System.out.println("2. UART output data does not be captured completely");
                        System.out.println("3. Other possible reasons ...");
                    }
                }
                //remove idle bits before the first start bit
                removeIndex_Length =(int) (startPatIndices.getElement(site,0)+7*captureEdge );//start bit
                rawData.set(site, rawData.get(site).removeValues(0,removeIndex_Length ));
            }
        }
//        rawData.plot("extract_new_wave");

        //get max match size
        int siteMatchSizeMax=0;
        for(int site:activeSite) {
            if(rawData.getSize(site)>siteMatchSizeMax) {
                siteMatchSizeMax=rawData.getSize(site);
            }
        }
        //extract valid bits
        MultiSiteLongArray uartReadDataArray=new MultiSiteLongArray((siteMatchSizeMax/captureEdge), 0);
        MultiSiteWaveLong tempWave_11bits = new MultiSiteWaveLong();
        MultiSiteWaveLong tempWave_8bits = new MultiSiteWaveLong();
        MultiSiteLong extractIndex_StartBitH=new MultiSiteLong();
        MultiSiteLong extractIndex_StartBitL=new MultiSiteLong();
        MultiSiteLong extractIndex_StopBitH=new MultiSiteLong();
        MultiSiteLong extractIndex_StopBitL=new MultiSiteLong();
        MultiSiteLong length_Extract=new MultiSiteLong(1);

        int lastRisingEdgeIndex = -1;
        int startIndex=-1;
        int stopIndex =-1;
        int splitSize_8bits = 0;
        int bitValue = 0;
        int count = 0;
        rawData = rawData.resize(new MultiSiteLong(siteMatchSizeMax));
        int maxDataSize=0;
        for(int site:activeSite){
            count=0;//initialize per site
            for(int i=0; i<rawData.getSize(site); i++){
                for(int siteEn:activeSite){
                    extractIndex_StartBitH.set(siteEn, i+ 0*captureEdge);
                    extractIndex_StartBitL.set(siteEn, i+ 1*captureEdge);
                    extractIndex_StopBitH .set(siteEn, i+ 9*captureEdge);
                    extractIndex_StopBitL .set(siteEn, i+10*captureEdge);
                }
                length_Extract .set(site, captureEdge);

                if( (i+11*captureEdge) <= rawData.getSize(site) ){
                    if( rawData.extractValues(extractIndex_StartBitH, length_Extract).mean().get(site) >= 0.750 &&
                        rawData.extractValues(extractIndex_StartBitL, length_Extract).mean().get(site) <= 0.250 &&
                        rawData.extractValues(extractIndex_StopBitH , length_Extract).mean().get(site) <= 0.250 &&
                        rawData.extractValues(extractIndex_StopBitL , length_Extract).mean().get(site) >= 0.750 ){

                        tempWave_11bits = rawData.extractValues(i, 11*captureEdge);
                        lastRisingEdgeIndex = tempWave_11bits.get(site).edges(0.5, EdgeType.RISING,SearchDirection.ASCENDING).length - 1;
                        startIndex = (int)(tempWave_11bits.edges(0.5, EdgeType.FALLING,  SearchDirection.ASCENDING).getElement(site, 0)+0.5+captureEdge);//Add captureEdge to remove start bit.
                        stopIndex  = (int)(tempWave_11bits.edges(0.5, EdgeType.RISING,   SearchDirection.ASCENDING).getElement(site, lastRisingEdgeIndex)-0.5);
                        tempWave_8bits = tempWave_11bits.extractValues(startIndex, (stopIndex+captureEdge/2)-startIndex);//Stop index add captureEdge/2 points to get appropriate splitSize_8bits value in division operation and avoid over size when extract value.
                        splitSize_8bits = tempWave_8bits.getSize(site)/8;
                        for(int j=0; j<7; j++){
                            bitValue=tempWave_8bits.extractValues(j*splitSize_8bits, splitSize_8bits).get(site).mean() >= 0.5?1:0;
                            uartReadDataArray.setElement( site, count, uartReadDataArray.getElement(site, count)+bitValue*(int)(Math.pow(2, j)) );
                        }
//                        System.out.println("data"+count+" Data= "+uartReadDataArray.getElement(site, count));
                        count++;
                        i = stopIndex+i;
                    }
                    if(count>maxDataSize) {
                        maxDataSize=count;
                    }
                }
            }
        }
        //restore raw data
        rawData.set(rawData_Copy);

        //resize  returnUart size to actual max data size
        MultiSiteLongArray returnUart=new MultiSiteLongArray(maxDataSize,0);
        returnUart.set(uartReadDataArray.toMultiSiteWave().resize(maxDataSize).toMultiSiteArray());

        return returnUart;
    }


}


