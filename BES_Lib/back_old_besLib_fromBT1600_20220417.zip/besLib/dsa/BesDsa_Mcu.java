package besLib.dsa;

import java.util.ArrayList;

import besLib.cal.BesTextProcess;
import besLib.enumeration.CMD_Mode.cmd_Mode;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupProtocolInterface;
import xoc.dsa.ISetupTransactionSeqDef;

public class BesDsa_Mcu {

    protected  IDeviceSetup ds;

    /**
     * Constructor function
     * @param ds an instance of IDeviceSetup interface
     */
    public BesDsa_Mcu(IDeviceSetup ds) {
        this.ds=ds;
    }


    /**
     * For BES bin file download to MCU RAM only
     * @param fileName bin file name with qualified path in the project
     *
     */
    public void ramRun_Uart( String fileName)  {
        if(fileName.contains(".bin")!=true){
            System.out.println("***************************************");
            System.out.println("** ERROR: filename suffix incorrect! **");
            System.out.println("***************************************");
        }

        //get bin file data
        ArrayList<Long> rawData=new BesTextProcess().binFileExtract(fileName);

        //generate UART communication format
        ArrayList<Long> handShake=new BesTextProcess().getCMDSeq(cmd_Mode.HandShake_Non_Secure_Boot, rawData);
        ArrayList<Long> downloadProgram=new BesTextProcess().getCMDSeq(cmd_Mode.Download_Program, rawData);
        ArrayList<Long> downloadRET=new BesTextProcess().getCMDSeq(cmd_Mode.Download_RET, rawData);
        ArrayList<Long> goProgram=new BesTextProcess().getCMDSeq(cmd_Mode.Go_Program, rawData);

        //PA
        ISetupProtocolInterface[] paInterface=new ISetupProtocolInterface[1];
        paInterface[0] = this.ds.addProtocolInterface("UART_BES_"+fileName.substring(fileName.lastIndexOf("/")+1,fileName.lastIndexOf(".")), "besLib.pa.UART_BES");
        paInterface[0].addSignalRole("RXD", "I2C_SCL");
        paInterface[0].addSignalRole("TXD", "I2C_SDA");
        ISetupTransactionSeqDef[] transDigSrc=new ISetupTransactionSeqDef[1];
        transDigSrc[0]= paInterface[0].addTransactionSequenceDef();
        for(int i=0;i<handShake.size();i++)         {transDigSrc[0].addTransaction("writeUart", handShake.get(i));}
        transDigSrc[0].addWait("5 ms");
        for(int i=0;i<downloadProgram.size();i++)   {transDigSrc[0].addTransaction("writeUart", downloadProgram.get(i));}
        transDigSrc[0].addWait("5 ms");
        for(int i=0;i<downloadRET.size();i++)       {transDigSrc[0].addTransaction("writeUart", downloadRET.get(i));}
        for(int i=0;i<rawData.size();i++)           {transDigSrc[0].addTransaction("writeUart", rawData.get(i));}
        transDigSrc[0].addWait("5 ms");
        for(int i=0;i<goProgram.size();i++)         {transDigSrc[0].addTransaction("writeUart", goProgram.get(i));}

        //OpSeq
        this.ds.transactionSequenceCall(transDigSrc[0]);
    }


}
