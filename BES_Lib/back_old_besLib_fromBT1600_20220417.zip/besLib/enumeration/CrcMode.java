package besLib.enumeration;

public class CrcMode {

    /**
     * Enum type for property of CRC checksum model.
     */
    public enum crcMode{
        CRC4_ITU,
        CRC5_EPC,
        CRC5_ITU,
        CRC5_USB,
        CRC6_ITU,
        CRC7_MMC,
        CRC8,
        CRC8_ITU,
        CRC8_ROHC,
        CRC8_MAXIM,
        CRC16_IBM,
        CRC16_MAXIM,
        CRC16_USB,
        CRC16_MODBUS,
        CRC16_CCITT,
        CRC16_CCITT_FALSE,
        CRC16_X25,
        CRC16_XMODEM,
        CRC16_DNP,
        CRC32,
        CRC32_MPEG_2,
    }

}
