package besLib.enumeration;

public class PayloadSeq {

    /**
     * Enum type for BT TX ModChar.
     */
    public enum payloadSeq{
        F0,
        AA,
    }

}
