package besLib.cal;

import java.util.ArrayList;

import besLib.enumeration.CrcMode.crcMode;
import besLib.enumeration.FreqCalMode.freqCalMode;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.dsp.Line;
import xoc.dta.datatypes.dsp.MultiSiteSpectrum;
import xoc.dta.datatypes.dsp.MultiSiteWaveLong;
import xoc.dta.datatypes.dsp.SpectrumUnit;
import xoc.dta.datatypes.dsp.WindowFunction;

public class BesCalc_General {

    /**
     * Calculate CRC checksum.<br>
     * @version 1.0
     * @param rawData Data to be used to calculate CRC checksum in ArrayList<Long> type
     * @param crcMode CRC mode
    *        <br>The options are: <i>CRC4_ITU,CRC8,CRC16_CCITT,CRC32,</i>...  <br>
     * @return CRC value in long type
     */
     public  Long getCRC(ArrayList<Long> rawData, crcMode crcMode) {
         long crc=0x0L;
         long poly=0x0L;
         long gx=0x0L;
         long data=0L;
         long crcXOROUT=0x0L;
         int  gxLen=0;
         int dataLen=8;
         boolean refIN=false;
         boolean refOUT=false;

         switch (crcMode) {
             case CRC4_ITU:
                 poly=0x13L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC5_EPC:
                 poly=0x29L;
                 crc=0x09L;
                 crcXOROUT=0x0L;
                 refIN=false;
                 refOUT=false;
                 break;
             case CRC5_ITU:
                 poly=0x35L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC5_USB:
                 poly=0x25L;
                 crc=0x1fL;
                 crcXOROUT=0x1fL;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC6_ITU:
                 poly=0x43L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC7_MMC:
                 poly=0x89L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=false;
                 refOUT=false;
                 break;
             case CRC8:
                 poly=0x107L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=false;
                 refOUT=false;
                 break;
             case CRC8_ITU:
                 poly=0x107L;
                 crc=0x0L;
                 crcXOROUT=0x55L;
                 refIN=false;
                 refOUT=false;
                 break;
             case CRC8_ROHC:
                 poly=0x107L;
                 crc=0xffL;
                 crcXOROUT=0x0L;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC8_MAXIM:
                 poly=0x131L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC16_IBM:
                 poly=0x18005L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC16_MAXIM:
                 poly=0x18005L;
                 crc=0x0L;
                 crcXOROUT=0xffffL;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC16_USB:
                 poly=0x18005L;
                 crc=0xffffL;
                 crcXOROUT=0xffffL;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC16_MODBUS:
                 poly=0x18005L;
                 crc=0xffffL;
                 crcXOROUT=0x0L;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC16_CCITT:
                 poly=0x11021L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC16_CCITT_FALSE:
                 poly=0x11021L;
                 crc=0xffffL;
                 crcXOROUT=0x0L;
                 refIN=false;
                 refOUT=false;
                 break;
             case CRC16_X25:
                 poly=0x11021L;
                 crc=0xffffL;
                 crcXOROUT=0xffffL;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC16_XMODEM:
                 poly=0x11021L;
                 crc=0x0L;
                 crcXOROUT=0x0L;
                 refIN=false;
                 refOUT=false;
                 break;
             case CRC16_DNP:
                 poly=0x13d65L;
                 crc=0x0L;
                 crcXOROUT=0xffffL;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC32:
                 poly=0x104c11db7L;
                 crc=0xffffffffL;
                 crcXOROUT=0xffffffffL;
                 refIN=true;
                 refOUT=true;
                 break;
             case CRC32_MPEG_2:
                 poly=0x104c11db7L;
                 crc=0xffffffffL;
                 crcXOROUT=0x0L;
                 refIN=false;
                 refOUT=false;
                 break;
         default:
             break;
         }

         for(int i=0; i<rawData.size();i++) {
             gx=poly; //CRC32
             gxLen=Long.toBinaryString(gx).length();

             //judge if reverse the byte
             if(refIN==true) {
                 data=(Long.reverse(rawData.get(i))>>(64-8) & 0xff);
             }
             else {
                 data=rawData.get(i);
             }
             // calculate (data^CRC_INIT)<<gxLen
             if((gxLen-1)<=dataLen) {
                 data=((crc<<(dataLen-(gxLen-1)))^data)<<(gxLen-1);
             }
             else {
                 data=((data<<((gxLen-1)-dataLen))^crc)<<dataLen;
             }
             // keep bit size of gx and data is same
             gx=gx<<(dataLen-1);
             // calculate CRC value
             for(int j=0;j<dataLen;j++) {
                 if( (data & (0x1L<<(gxLen-1+dataLen-1)))!=0) {//judge if the highest bit is 1 or 0
                     data=data^gx;
                     data=data<<1;
                 }
                 else {
                     data=data<<1;
                 }
             }
             crc=data>>dataLen; //get crc value
         }
         //judge if reverse the byte
         if(refOUT==true) {
             crc=( Long.reverse(crc)>>>(64-(gxLen-1)) );
         }
         return crc^crcXOROUT;
     }

     /**
      * Calculate CRC checksum.<br>
      * ********************************** <br>
      * ** Pay attention to the data type! ** <br>
      * ********************************** <br>
      * The default data type of java is 'int'. If value <i>'crcInit'<i> has more than 32 bits , remember to add the suffix <i>'L'<i><br>
      * @version 1.0
      * @param poly CRC Polynomial
      * @param rawData Data to be used to calculate CRC checksum in ArrayList<Long> type
      * @param crcInit CRC register initial value in long type.
      * @return CRC value in long type
      */
      public  Long getCRC(ArrayList<Long> rawData,long poly,long crcInit,long crcXOROUT,boolean refIN,boolean refOUT) {
          long crc=crcInit;
          long gx=0x0L;
          long data=0L;
          int  gxLen=0;
          int dataLen=8;

          for(int i=0; i<rawData.size();i++) {
              gx=poly; //CRC32
              gxLen=Long.toBinaryString(gx).length();

              //judge if reverse the byte
              if(refIN==true) {
                  data=(Long.reverse(rawData.get(i))>>(64-8) & 0xff);
              }
              else {
                  data=rawData.get(i);
              }
              // calculate (data^CRC_INIT)<<gxLen
              if((gxLen-1)<=dataLen) {
                  data=((crc<<(dataLen-(gxLen-1)))^data)<<(gxLen-1);
              }
              else {
                  data=((data<<((gxLen-1)-dataLen))^crc)<<dataLen;
              }
              // keep bit size of gx and data is same
              gx=gx<<(dataLen-1);
              // calculate CRC value
              for(int j=0;j<dataLen;j++) {
                  if( (data & (0x1L<<(gxLen-1+dataLen-1)))!=0) {//judge if the highest bit is 1 or 0
                      data=data^gx;
                      data=data<<1;
                  }
                  else {
                      data=data<<1;
                  }
              }
              crc=data>>dataLen; //get crc value
          }
          //judge if reverse the byte
          if(refOUT==true) {
              crc=( Long.reverse(crc)>>>(64-(gxLen-1)) );
          }
          return crc^crcXOROUT;
      }



      /**
       * calculate frequency
       * @param rawData vector data captured per bit in MultiSiteWaveLong data type
       * @param period_us sample period in us unit
       * @param freqCalMode freqCalMode
       *        <br>The options are: <i>FFT,LinearFit,EdgeCount</i>...  <br>
       * @return frequency value in MultiSiteDouble data type in MHz unit
       */
      public MultiSiteDouble freqCal(MultiSiteWaveLong rawData, double period_us, freqCalMode freqCalMode)
      {
          int[] activeSites = rawData.getActiveSites();
          MultiSiteDouble frequency_MHz=new MultiSiteDouble();

          if(freqCalMode.toString().compareTo("FFT")==0) {
              MultiSiteSpectrum spec=rawData.setWindowFunction(WindowFunction.HANNING).spectrum(SpectrumUnit.V);
              for(int site:activeSites)
              {
                  //cancel out the potential max bin at DC
                  if (spec.getSize(site)>2) {
                      spec.setValue(site, 0, 0);
                      spec.setValue(site, 1, 0);
                  }
                  else {
                     System.out.println("/************************************************/");
                     System.out.println("Warning: Site "+site+" Spectrum data is too small!");
                     System.out.println("/************************************************/");
                  }
                  int max_index=spec.get(site).maxIndex();
                  int max_index_plus_one=max_index+1;
                  max_index_plus_one=(max_index_plus_one<spec.getSize(site))?max_index_plus_one:max_index_plus_one-1;
                  //interpolating equations
                  double dR,interpol_index;
                  if( (max_index>0) && (spec.getValue(site, max_index-1)>spec.getValue(site, max_index_plus_one)) ){
                      dR=spec.getValue(site, max_index-1)/spec.getValue(site, max_index);
                      interpol_index=max_index+(1.0-2.0*dR)/(1.0+dR);
                  }
                  else {
                      dR=spec.getValue(site, max_index_plus_one)/spec.getValue(site, max_index);
                      interpol_index=max_index-(1.0-2.0*dR)/(1.0+dR);
                  }
                  double freq_MHz_site=interpol_index/(period_us*rawData.getSize(site));
                  frequency_MHz.set(site, freq_MHz_site);
              }
          }
          else if(freqCalMode.toString().compareTo("LinearFit")==0) {
              MultiSiteWaveLong rising_edge=new MultiSiteWaveLong((rawData.getSize(activeSites[0])));
              int i,j;
              for(int site:activeSites) {
                  for(i=0,j=0;i<rawData.getSize(site)-1;i++) {
                      if(rawData.getValue(site, i)<rawData.getValue(site, i+1)) {
                          rising_edge.setValue(site, j++, i);
                      }
                  }
                  Line result1=new Line();
                  try {
                      result1=rising_edge.get(site).extractValues(0, j).regressionLine();
                  } catch (Exception e) {
                      // TODO: handle exception
                  }
                  double freq_MHz_site=1/(period_us*result1.getSlope());
                  frequency_MHz.set(site, freq_MHz_site);
              }
          }
          else if(freqCalMode.toString().compareTo("EdgeCount")==0) {
              int array_size=rawData.getSize(activeSites[0]);
              for(int site:activeSites) {
                  int i=0,j=0;
                  int first_edge=0,last_edge=1;
                  int low=0;
                  int cycle_count=0;
                  if(rawData.getValue(site, 0)==0) { //first edge is rising edge
                      for(j=1;j<array_size;j++) {
                          if(rawData.getValue(site, j)>0) {
                              first_edge=j;
                              low=0;
                              break;
                          }
                      }
                      for(i=++j;i<array_size;i++) {
                          if(rawData.getValue(site, i)==0) {
                              low=1;
                          }
                          else {
                              if(low!=0) {
                                  cycle_count++;
                                  last_edge=i;
                              }
                              low=0;
                          }
                      }
                  }
                  else { //first edge is falling edge
                      for(j=1;j<array_size;j++) {
                          if(rawData.getValue(site, j)==0) {
                              first_edge=j;
                              low=0;
                              break;
                          }
                      }
                      for(i=++j;i<array_size;i++) {
                          if(rawData.getValue(site, i)>0) {
                              low=1;
                          }
                          else {
                              if(low!=0) {
                                  cycle_count++;
                                  last_edge=i;
                              }
                              low=0;
                          }
                      }
                  }
                  double freq_calc=0;
                  if(cycle_count==0) {
                      freq_calc=-1.0;
                  }
                  else {
                      freq_calc=cycle_count/((last_edge-first_edge)*period_us);
                  }
                  frequency_MHz.set(site, freq_calc);
              }
          }
          return frequency_MHz;
      }

}
