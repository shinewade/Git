package besLib.dsa;

import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupProtocolInterface;

public class BesDsa_Dc {

    protected IDeviceSetup ds;
    protected ISetupProtocolInterface[] paInterface;


    /**
     * Constructor function
     * @param ds an instance of IDeviceSetup interface
     */
    public BesDsa_Dc(IDeviceSetup ds)  {
        this.ds=ds;
    }

//    public void vf_Dcvi_Dps64(String dpsPin, double forceValue, double iClamp,boolean disconnect,SetupDisconnectMode SetupDisconnectMode) {
//        ISetupDcVI[] dcvi=new ISetupDcVI[1];
//        dcvi[0]=this.ds.addDcVI(dpsPin).setConnect(true).setDisconnect(disconnect).setDisconnectMode(SetupDisconnectMode);
//        dcvi[0].level().setIrange("500 mA").setVrange("6 V");
//        dcvi[0].vforce("vf_"+dpsPin+"_"+String.valueOf(forceValue).replace(".", "p")).setForceValue(forceValue).setIrange("500 mA").setIclamp(iClamp);
//        this.ds.actionCall("vf_"+dpsPin+"_"+String.valueOf(forceValue).replace(".", "p"));
//    }
//
//    public String vfim_Dcvi_Dps64(String dpsPin, double forceValue) {
//        ISetupDcVI[] dcvi=new ISetupDcVI[1];
//        dcvi[0]=this.ds.addDcVI(dpsPin).setConnect(true).setDisconnect(true).setDisconnectModeHiz();
//        dcvi[0].level().setIrange("500 mA").setVrange("6 V");
//        dcvi[0].vforce("vfim_"+dpsPin+"_"+String.valueOf(forceValue).replace(".", "p")).setForceValue(forceValue).setIrange("500 mA").setIclamp("500 mA");
//        dcvi[0].imeas("im_"+dpsPin).setIrange("50 mA").setAverages(32).setWaitTime("45 ms").setRestoreIrange(true);
//
//        this.ds.actionCall("");
//
//        return "im_"+dpsPin;
//    }

}
