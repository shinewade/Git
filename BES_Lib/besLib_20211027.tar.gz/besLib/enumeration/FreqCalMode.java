package besLib.enumeration;

public class FreqCalMode {

    /**
     * Enum type for property of frequency calibration model.
     */
    public enum freqCalMode{
        FFT,
        LinearFit,
        EdgeCount,
    }

}
