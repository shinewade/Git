package besLib.enumeration;

public class RFSwitch {
    /**
     * Enum type for RF switch MXD8730.
     */
    public enum MXD8730{
        RF1,
        RF2,
        RF3,
    }
}
