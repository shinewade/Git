package besLib.cal;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class BesLabViewTextProcess {


    /**
    * Extract valid data from BES LabView reg_config Text file
    * @version 1.0
    * @param filename Test file name with qualified path in the project
    * @return Valid data in ArrayList<String> Type
    */
    public ArrayList<String> getRegFromFile(String filename,String labelName){

//        String DeviceName = "";
        String startAddress = "0x00";
        boolean pageTurnFlag = false;
        if(filename.contains("PMU_Reg"))
        {
            startAddress = "0x00";
            pageTurnFlag = true;
        }
        else if(filename.contains("P180"))
        {
            startAddress = "0x00";
            pageTurnFlag = true;
        }
        else if(filename.contains("RF_Reg"))
        {
            startAddress = "0x00";
            pageTurnFlag = true;
        }
        else if(filename.contains("ANA_Reg"))
        {
            startAddress = "0x00";
            pageTurnFlag = true;
        }
        else if(filename.contains("RC_Reg"))
        {
            startAddress = "0x00";
            pageTurnFlag = true;
        }
        else if(filename.contains("XTAL_Reg"))
        {
            startAddress = "0x00";
            pageTurnFlag = true;
        }
        else if(filename.contains("EMMC_Reg"))
        {
            startAddress = "0x00";
            pageTurnFlag = true;
        }
        else if(filename.contains("PCIE_Reg"))
        {
            startAddress = "0x00";
            pageTurnFlag = true;
        }
        else if(filename.contains("BT1000_Dig_Reg"))
        {
            startAddress = "";
            pageTurnFlag = false;
        }
        else if(filename.contains("USB_Reg"))
        {
            startAddress = "";
            pageTurnFlag = false;
        }
        else if(filename.contains("CHARGER_Reg"))
        {
            startAddress = "";
            pageTurnFlag = false;
        }
        else
        {
            System.out.println("ERROR : Unable to distinguish device type, please standardize file name. *** "+labelName);
        }

        ArrayList<String> regListTemp = new ArrayList<String>();
        @SuppressWarnings("resource")
        BufferedReader br = null;
        String lineData = "";
        try {
            br = new BufferedReader(new FileReader(filename));
            boolean start_flag = false;
            while ((lineData = br.readLine())!= null) {
//                System.out.println(lineData);
                if(start_flag == true)
                {
                    if( (lineData.contains("0x") && lineData.contains(",") && (!lineData.contains("[")) && (!lineData.contains("]")))
                        || lineData.isEmpty() || lineData.contains("//") || lineData.contains("wait")  || lineData.contains(";") )
                    {
                        if(lineData.contains(";"))
                        {
                            if( (lineData.indexOf("0x")<lineData.indexOf(",")) && (lineData.indexOf(",") <lineData.indexOf(";")) )
                            {
//                                System.out.println(lineData.indexOf("0x"));
//                                System.out.println(lineData.indexOf(","));
//                                System.out.println(lineData.indexOf(";"));
//                                System.out.println();
                                if(lineData.contains("//"))
                                {
                                    if(lineData.indexOf(";")<lineData.indexOf("//"))
                                    {
                                        regListTemp.add(lineData.substring(0, lineData.indexOf(";")).replaceAll(" ", ""));
                                    }
                                    else
                                    {
//                                        System.out.println("*** ERROR : The data formoat of this line in source text file is not normal : '"+lineData+"' *** "+labelName);
                                    }
                                }
                                else
                                {
                                    regListTemp.add(lineData.substring(0, lineData.indexOf(";")).replaceAll(" ", ""));
                                }
                            }
                            else
                            {
//                                System.out.println("*** ERROR : The data formoat of this line in source text file is not normal : '"+lineData+"' *** "+labelName);
                            }
                        }
                        else
                        {
                            if(lineData.indexOf("0x")<lineData.indexOf(","))
                            {
                                if(lineData.contains("//"))
                                {
                                    if(lineData.indexOf(",")<lineData.indexOf("//"))
                                    {
                                        regListTemp.add(lineData.substring(0, lineData.indexOf("//")).replaceAll(" ", ""));
                                    }
                                    else
                                    {
//                                        System.out.println("*** ERROR : The data formoat of this line in source text file is not normal : '"+lineData+"' *** "+labelName);
                                    }
                                }
                                else
                                {
                                    regListTemp.add(lineData.replaceAll(" ", ""));
                                }
                            }
                            else
                            {
//                                System.out.println("*** ERROR : The data formoat of this line in source text file is not normal : '"+lineData+"' *** "+labelName);
                            }
                        }
                    }
                    else
                    {
                        start_flag = false;
                    }
                }
                if((start_flag==false) && lineData.equals(labelName))
                {
                    start_flag = true;
                }
                else
                {
//                    System.out.println("ERROR: Can't find the label : "+labelName+" Doesn't exist!");
                }
            }
        }catch (FileNotFoundException e)
        {
            e.printStackTrace();
            System.out.println("ERROR: filename "+filename+" doesn't exist!");
        }catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(br != null) {
                try {
                    br.close();
                }catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

//        System.out.println(regListTemp);

        ArrayList<String> regList = new ArrayList<String>();
        for(int i=0; i<regListTemp.size()-1; i++)
        {
            if(pageTurnFlag)
            {
//                System.out.println(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")));
//                System.out.println(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).length());
                if(regListTemp.get(i).contains("wait"))
                {
                    if(i == 0)
                    {
                        regList.add(regListTemp.get(i));
                        if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==3)
                        {
                            if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("1"))
                            {
                                regList.add(startAddress+",0xa010");
                            }
                            else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("2"))
                            {
                                regList.add(startAddress+",0xa020");
                            }
                            else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("3"))
                            {
                                regList.add(startAddress+",0xa030");
                            }
                            else
                            {
                                System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                            }
                            regList.add(regListTemp.get(i+1).substring(0, 2).concat(regListTemp.get(i+1).substring(3, regListTemp.get(i+1).length())));
                        }
                        else
                        {
                            regList.add(regListTemp.get(i+1));
                        }
                    }
                    else
                    {
                        if(regListTemp.get(i-1).substring(regListTemp.get(i-1).indexOf("0x")+2, regListTemp.get(i-1).indexOf(",")).length()==2 &&
                           regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==2
                           )
                         {
//                             System.out.println(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1));
                             if(i==1)
                             {
                                 regList.add(regListTemp.get(i-1));
                             }
                             regList.add(regListTemp.get(i));
                             regList.add(regListTemp.get(i+1));
                         }
                         if(regListTemp.get(i-1).substring(regListTemp.get(i-1).indexOf("0x")+2, regListTemp.get(i-1).indexOf(",")).length()==2 &&
                            regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==3
                           )
                         {
//                             System.out.println(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1)=="1");
                             if(i==1)
                             {
                                 regList.add(regListTemp.get(i-1));
                             }
                             regList.add(regListTemp.get(i));
                             if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("1"))
                             {
                                 regList.add(startAddress+",0xa010");
                             }
                             else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("2"))
                             {
                                 regList.add(startAddress+",0xa020");
                             }
                             else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("3"))
                             {
                                 regList.add(startAddress+",0xa030");
                             }
                             else
                             {
                                 System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                             }
                             regList.add(regListTemp.get(i+1).substring(0, 2).concat(regListTemp.get(i+1).substring(3, regListTemp.get(i+1).length())));
                         }
                         if(regListTemp.get(i-1).substring(regListTemp.get(i-1).indexOf("0x")+2, regListTemp.get(i-1).indexOf(",")).length()==3 &&
                            regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==2
                           )
                         {
                             if(i==1)
                             {
                                 if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("1"))
                                 {
                                     regList.add(startAddress+",0xa010");
                                 }
                                 else if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("2"))
                                 {
                                     regList.add(startAddress+",0xa020");
                                 }
                                 else if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("3"))
                                 {
                                     regList.add(startAddress+",0xa030");
                                 }
                                 else
                                 {
                                     System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                                 }
                                 regList.add(regListTemp.get(i-1).substring(0, 2).concat(regListTemp.get(i-1).substring(3, regListTemp.get(i-1).length())));
                             }
                             regList.add(startAddress+",0xa000");
                             regList.add(regListTemp.get(i));
                             regList.add(regListTemp.get(i+1));
                         }
                         if(regListTemp.get(i-1).substring(regListTemp.get(i-1).indexOf("0x")+2, regListTemp.get(i-1).indexOf(",")).length()==3 &&
                            regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==3
                           )
                         {
         //                    System.out.println(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1));
                             if(i==1)
                             {
                                 if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("1"))
                                 {
                                     regList.add(startAddress+",0xa010");
                                 }
                                 else if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("2"))
                                 {
                                     regList.add(startAddress+",0xa020");
                                 }
                                 else if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("3"))
                                 {
                                     regList.add(startAddress+",0xa030");
                                 }
                                 else
                                 {
                                     System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                                 }
                                 regList.add(regListTemp.get(i-1).substring(0, 2).concat(regListTemp.get(i-1).substring(3, regListTemp.get(i-1).length())));
                             }
                             regList.add(regListTemp.get(i));
                             if(!regListTemp.get(i-1).substring(regListTemp.get(i-1).indexOf("0x")+2, regListTemp.get(i-1).indexOf(",")).substring(0, 1)
                                .equals(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1)))
                             {
                                 if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("1"))
                                 {
                                     regList.add(startAddress+",0xa010");
                                 }
                                 else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("2"))
                                 {
                                     regList.add(startAddress+",0xa020");
                                 }
                                 else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("3"))
                                 {
                                     regList.add(startAddress+",0xa030");
                                 }
                                 else
                                 {
                                     System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                                 }
                             }
                             regList.add(regListTemp.get(i+1).substring(0, 2).concat(regListTemp.get(i+1).substring(3, regListTemp.get(i+1).length())));
                         }
                    }
                }
                else
                {
                    if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).length()==2 &&
                       regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==2
                      )
                    {
    //                    System.out.println(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1));
                        if(i ==0)
                        {
                            regList.add(regListTemp.get(i));
                        }
                        regList.add(regListTemp.get(i+1));
                    }
                    if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).length()==2 &&
                       regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==3
                      )
                    {
    //                    System.out.println(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1)=="1");
                        if(i ==0)
                        {
                            regList.add(regListTemp.get(i));
                        }
                        if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("1"))
                        {
                            regList.add(startAddress+",0xa010");
                        }
                        else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("2"))
                        {
                            regList.add(startAddress+",0xa020");
                        }
                        else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("3"))
                        {
                            regList.add(startAddress+",0xa030");
                        }
                        else
                        {
                            System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                        }
                        regList.add(regListTemp.get(i+1).substring(0, 2).concat(regListTemp.get(i+1).substring(3, regListTemp.get(i+1).length())));
                    }
                    if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).length()==3 &&
                       regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==2
                      )
                    {
                        if(i==0)
                        {
                            if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("1"))
                            {
                                regList.add(startAddress+",0xa010");
                            }
                            else if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("2"))
                            {
                                regList.add(startAddress+",0xa020");
                            }
                            else if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("3"))
                            {
                                regList.add(startAddress+",0xa030");
                            }
                            else
                            {
                                System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                            }
                            regList.add(regListTemp.get(i).substring(0, 2).concat(regListTemp.get(i).substring(3, regListTemp.get(i).length())));
                        }
                        regList.add(startAddress+",0xa000");
                        regList.add(regListTemp.get(i+1));
                    }
                    if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).length()==3 &&
                       regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==3
                      )
                    {
    //                    System.out.println(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1));
                        if(i==0)
                        {
                            if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("1"))
                            {
                                regList.add(startAddress+",0xa010");
                            }
                            else if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("2"))
                            {
                                regList.add(startAddress+",0xa020");
                            }
                            else if(regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1).equals("3"))
                            {
                                regList.add(startAddress+",0xa030");
                            }
                            else
                            {
                                System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                            }
                            regList.add(regListTemp.get(i).substring(0, 2).concat(regListTemp.get(i).substring(3, regListTemp.get(i).length())));
                        }
                        if(!regListTemp.get(i).substring(regListTemp.get(i).indexOf("0x")+2, regListTemp.get(i).indexOf(",")).substring(0, 1)
                           .equals(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1)))
                        {
                            if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("1"))
                            {
                                regList.add(startAddress+",0xa010");
                            }
                            else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("2"))
                            {
                                regList.add(startAddress+",0xa020");
                            }
                            else if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).substring(0, 1).equals("3"))
                            {
                                regList.add(startAddress+",0xa030");
                            }
                            else
                            {
                                System.out.println("*** ERROR : Over Range page turn *** " +labelName);
                            }
                        }
                        regList.add(regListTemp.get(i+1).substring(0, 2).concat(regListTemp.get(i+1).substring(3, regListTemp.get(i+1).length())));
                    }

                    if(i+2 == regListTemp.size())
                    {
    //                    System.out.println(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length());
                        if(regListTemp.get(i+1).substring(regListTemp.get(i+1).indexOf("0x")+2, regListTemp.get(i+1).indexOf(",")).length()==3)
                        {
                            regList.add(startAddress+",0xa000");
                        }
                        if(regListTemp.get(i+1).contains("wait"))
                        {
                            regList.add(regListTemp.get(i+1));
                        }
                    }
                }
            }
            else
            {
                regList.add(regListTemp.get(i));
//                System.out.println(regList.add(regListTemp.get(i)));
                if(i+2 == regListTemp.size())
                {
                    regList.add(regListTemp.get(i+1));
                }
            }
        }

//        System.out.println(regList);

//        System.out.println("***"+regListTemp.get(0));
        if(regListTemp.size() == 1)
        {
            return regListTemp;
        }
        return regList;
    }

}
