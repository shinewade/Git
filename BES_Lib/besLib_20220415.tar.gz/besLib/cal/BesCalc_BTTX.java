package besLib.cal;

import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.datatypes.MultiSiteLong;
import xoc.dta.datatypes.dsp.MultiSiteSpectrum;
import xoc.dta.datatypes.dsp.MultiSiteWaveComplex;
import xoc.dta.datatypes.dsp.SpectrumUnit;

/**
 * This class is used to calculate BES BT TX parameter
 * @version V1.0
 * @author Weng Yongxin
 **/
public class BesCalc_BTTX  {

    protected double binResolution;
    protected int signalBinCount;
    protected int[] activeSites;
    protected MultiSiteWaveComplex btWaveComplex = new MultiSiteWaveComplex();
    protected MultiSiteSpectrum tx_spectrum_dBm=new MultiSiteSpectrum();
    protected MultiSiteSpectrum tx_spectrum_mW=new MultiSiteSpectrum();
    protected MultiSiteLong rfBinIndex=new MultiSiteLong();
    protected MultiSiteLong loBinIndex=new MultiSiteLong();
    protected MultiSiteLong imagBinIndex=new MultiSiteLong();
    protected MultiSiteDouble powerRf=new MultiSiteDouble();
    protected MultiSiteDouble powerLo=new MultiSiteDouble();
    protected MultiSiteDouble powerImag=new MultiSiteDouble();
    protected MultiSiteDouble att=new MultiSiteDouble(0);
    protected boolean isLoRight = true;

    /**
     * Constructor function
     * @param btWaveComplex raw data captured by WSRF digitizer
     * @param signalBinCount bin number to calculate the integral of spectrum power
     * @param isLoRight LO is in the right of RF Signal or not
     */
    public BesCalc_BTTX(MultiSiteWaveComplex btWaveComplex, int signalBinCount,boolean isLoRight) {
        this.isLoRight = isLoRight;
        this.btWaveComplex.set(btWaveComplex);
        this.signalBinCount=signalBinCount;
        this.tx_spectrum_mW=this.btWaveComplex.spectrum(SpectrumUnit.mW);
        this.tx_spectrum_dBm=this.btWaveComplex.spectrum(SpectrumUnit.dBm);
        this.activeSites=this.btWaveComplex.getActiveSites();
        this.binResolution=(this.btWaveComplex.getSampleRate().get(this.activeSites[0]))/(this.btWaveComplex.getSize(this.activeSites[0]))/1000;//KHz
        this.rfBinIndex=this.tx_spectrum_mW.maxIndex();
        //calculate RF,LO,IMAG
        for(int site:activeSites)
        {
            try
            {
                if(this.isLoRight == true){
                    //LO spectrum BW: Frf + 120 KHz ~ Frf +200 KHz
                    this.loBinIndex  .set(site, this.rfBinIndex.getAsInt(site) + (int)(120/this.binResolution) + this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)+(int)(120/this.binResolution),(int)(80/this.binResolution)).maxIndex());
                    //Imagine spectrum BW: Frf + 280 KHz ~ Frf + 360 KHz
                    this.imagBinIndex.set(site, this.rfBinIndex.getAsInt(site) + (int)(280/this.binResolution) + this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)+(int)(280/this.binResolution),(int)(80/this.binResolution)).maxIndex());
                }
                else{
                    //LO spectrum BW: Frf - 200 KHz ~ Frf - 120 KHz
                    this.loBinIndex  .set(site, this.rfBinIndex.getAsInt(site) - (int)(200/this.binResolution) + this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)-(int)(200/this.binResolution),(int)(80/this.binResolution)).maxIndex());
                    //Imagine spectrum BW: Frf - 360 KHz ~ Frf - 280 KHz
                    this.imagBinIndex.set(site, this.rfBinIndex.getAsInt(site) - (int)(360/this.binResolution) + this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)-(int)(360/this.binResolution),(int)(80/this.binResolution)).maxIndex());
                }
            }
            catch (Exception e)
            {
                System.out.println("site "+site+" Spectrum abnormal, please check it!");
            }

            try
            {
                this.powerRf  .set(site, this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex  .getAsInt(site)-(this.signalBinCount-1)/2 ,this.signalBinCount).sum());
                this.powerLo  .set(site, this.tx_spectrum_mW.get(site).extractValues(this.loBinIndex  .getAsInt(site)-(this.signalBinCount-1)/2 ,this.signalBinCount).sum());
                this.powerImag.set(site, this.tx_spectrum_mW.get(site).extractValues(this.imagBinIndex.getAsInt(site)-(this.signalBinCount-1)/2 ,this.signalBinCount).sum());
            }
            catch (Exception e) {
                System.out.println("site "+site+"getRfPowerl/getLoPowerl/getImagPowerl error, please check Spectrum or extract bin!");
            }
        }
    }

    /**
     * Constructor function default LO is in the right of RF signal
     * @param btWaveComplex raw data captured by WSRF digitizer
     * @param signalBinCount bin number to calculate the integral of spectrum power
     */
    public BesCalc_BTTX(MultiSiteWaveComplex btWaveComplex, int signalBinCount) {
        this.btWaveComplex.set(btWaveComplex);
        this.signalBinCount=signalBinCount;
        this.tx_spectrum_mW=this.btWaveComplex.spectrum(SpectrumUnit.mW);
        this.tx_spectrum_dBm=this.btWaveComplex.spectrum(SpectrumUnit.dBm);
        this.activeSites=this.btWaveComplex.getActiveSites();
        this.binResolution=(this.btWaveComplex.getSampleRate().get(this.activeSites[0]))/(this.btWaveComplex.getSize(this.activeSites[0]))/1000;//KHz
        this.rfBinIndex=this.tx_spectrum_mW.maxIndex();
        //calculate RF,LO,IMAG
        for(int site:activeSites)
        {
            try
            {
                if(this.isLoRight == true){
                    //LO spectrum BW: Frf + 120 KHz ~ Frf +200 KHz
                    this.loBinIndex  .set(site, this.rfBinIndex.getAsInt(site) + (int)(120/this.binResolution) + this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)+(int)(120/this.binResolution),(int)(80/this.binResolution)).maxIndex());
                    //Imagine spectrum BW: Frf + 280 KHz ~ Frf + 360 KHz
                    this.imagBinIndex.set(site, this.rfBinIndex.getAsInt(site) + (int)(280/this.binResolution) + this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)+(int)(280/this.binResolution),(int)(80/this.binResolution)).maxIndex());
                }
                else{
                    //LO spectrum BW: Frf - 200 KHz ~ Frf - 120 KHz
                    this.loBinIndex  .set(site, this.rfBinIndex.getAsInt(site) - (int)(200/this.binResolution) + this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)-(int)(200/this.binResolution),(int)(80/this.binResolution)).maxIndex());
                    //Imagine spectrum BW: Frf - 360 KHz ~ Frf - 280 KHz
                    this.imagBinIndex.set(site, this.rfBinIndex.getAsInt(site) - (int)(360/this.binResolution) + this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)-(int)(360/this.binResolution),(int)(80/this.binResolution)).maxIndex());
                }
            }
            catch (Exception e)
            {
                System.out.println("site "+site+" Spectrum abnormal, please check it!");
            }

            try
            {
                this.powerRf  .set(site, this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex  .getAsInt(site)-(this.signalBinCount-1)/2 ,this.signalBinCount).sum());
                this.powerLo  .set(site, this.tx_spectrum_mW.get(site).extractValues(this.loBinIndex  .getAsInt(site)-(this.signalBinCount-1)/2 ,this.signalBinCount).sum());
                this.powerImag.set(site, this.tx_spectrum_mW.get(site).extractValues(this.imagBinIndex.getAsInt(site)-(this.signalBinCount-1)/2 ,this.signalBinCount).sum());
            }
            catch (Exception e) {
                System.out.println("site "+site+"getRfPowerl/getLoPowerl/getImagPowerl error, please check Spectrum or extract bin!");
            }
        }
    }

    /**
     * set value of attenuation in dBm.
     */
    public void setAtt(MultiSiteDouble att) {
        this.att.set(att);
    }

    /**
     * get spectrum in dBm.
     * @return spectrum in unit dBm.
     */
    public MultiSiteSpectrum getSpectrum_dBm() {
        return this.tx_spectrum_dBm;
    }

    /**
     * get spectrum getBinResolution.
     * @return Bin Resolution in unit KHz.
     */
    public double getBinResolution() {
        return this.binResolution;
    }

    /**
     * calculate the max tone power in unit dBm near the specified frequency to the left or right of RF signal tone.
     * @param FreqkHz   Target frequency.
     * @param isLoRight Target frequency tone is in the right of RF Signal or not.
     * @return The max tone power in unit dBm near the specified frequency (kHz).
     */
    public MultiSiteDouble getSpecificFreqRangeMaxTonePower_dBm(MultiSiteLong FreqkHz ,boolean isRightOfRFSignal) {
        MultiSiteDouble SpecificFreqPower=new MultiSiteDouble(0);
        MultiSiteLong maxIndex = new MultiSiteLong(0);
        for(int site:activeSites)
        {
            try
            {
                //spectrum BW: FreqkHz -40 KHz ~ FreqkHz +40 KHz
                if(isRightOfRFSignal)
                {
                    maxIndex.set(site, this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)+(int)((FreqkHz.getAsInt(site)-40)/this.binResolution) , (int)(80/this.binResolution)).maxIndex());
                    maxIndex.set(site, this.rfBinIndex.getAsInt(site)+(int)((FreqkHz.getAsInt(site)-40)/this.binResolution)+maxIndex.getAsInt(site));
                }
                else
                {
                    maxIndex.set(site, this.tx_spectrum_mW.get(site).extractValues(this.rfBinIndex.getAsInt(site)-(int)((FreqkHz.getAsInt(site)-40)/this.binResolution) , (int)(80/this.binResolution)).maxIndex());
                    maxIndex.set(site, this.rfBinIndex.getAsInt(site)-(int)((FreqkHz.getAsInt(site)+40)/this.binResolution)+maxIndex.getAsInt(site));
                }
                try
                {
                    SpecificFreqPower.set(site, this.tx_spectrum_mW.get(site).extractValues(maxIndex.getAsInt(site)-(this.signalBinCount-1)/2 ,this.signalBinCount).sum());
                }
                catch (Exception e)
                {
                    // TODO: handle exception
                }
            }
            catch (Exception e)
            {
                // TODO: handle exception
            }
        }

        return SpecificFreqPower.log10().multiply(10).add(this.att);
    }

    /**
     * calculate specific bin power in unit mW excludes ATT.
     * @return specific bin power in unit mW .
     */
    public MultiSiteDouble getSpecificBinPower_mW(MultiSiteLong startBin, MultiSiteLong stopBin) {
        MultiSiteDouble SpecificBinPower=new MultiSiteDouble(0);
        for(int site:activeSites)
        {
            try
            {
                SpecificBinPower.set(site, this.tx_spectrum_mW.get(site).extractValues(startBin.getAsInt(site) ,stopBin.getAsInt(site)-startBin.getAsInt(site)).sum());
            }
            catch (Exception e)
            {
                // TODO: handle exception
            }
        }

        return SpecificBinPower;
    }

    /**
     * calculate the power of max tone in specified bin range in unit mW excludes ATT.
     * @return The max tone power in specified bin range in unit mW .
     */
    public MultiSiteDouble getSpecificBinRangeMaxTonePower_mW(MultiSiteLong startBin, MultiSiteLong stopBin) {
        MultiSiteDouble maxTonePower=new MultiSiteDouble(0);
        MultiSiteLong maxIndex = new MultiSiteLong(0);
        for(int site:activeSites)
        {
            try
            {
                maxIndex.set(site, this.tx_spectrum_mW.get(site).extractValues(startBin.getAsInt(site) ,stopBin.getAsInt(site)-startBin.getAsInt(site)).maxIndex());
                maxTonePower.set(site, this.tx_spectrum_mW.get(site).extractValues(maxIndex.getAsInt(site)-(this.signalBinCount-1)/2 ,this.signalBinCount).sum());
            }
            catch (Exception e)
            {
                // TODO: handle exception
            }
        }

        return maxTonePower;
    }

    /**
     * calculate RF signal power.
     * @return RF signal power in unit dBm.
     */
    public MultiSiteDouble getRfPower_dBm() {
        return this.powerRf.log10().multiply(10).add(this.att);
    }

    /**
     * calculate LO signal power.
     * @return LO signal power in unit dBm.
     */
    public MultiSiteDouble getLoPower_dBm() {
        return this.powerLo.log10().multiply(10).add(this.att);
    }

    /**
     * calculate Imagine signal power.
     * @return Imagine signal power in unit dBm.
     */
    public MultiSiteDouble getImagPower_dBm() {
        return this.powerImag.log10().multiply(10).add(this.att);
    }

    /**
     * calculate RF signal frequency.
     * @param freqExpected_MHz expected frequency in MHz.
     * @return RF signal frequency in unit Hz.
     */
    public MultiSiteDouble getRfFrequency(double freqExpected_MHz ) {
        MultiSiteDouble freqRf=new MultiSiteDouble(0);
        for(int site:activeSites)
        {
            try
            {
                freqRf.set(site,freqExpected_MHz-(this.tx_spectrum_mW.getSize(site)/2-this.rfBinIndex.getAsInt(site))*this.binResolution/1e3);
            }
            catch (Exception e)
            {
                // TODO: handle exception
            }
        }
//        try
//        {
//            freqRf.set(new MultiSiteDouble(freqExpected_MHz).subtract((this.tx_spectrum_mW.getSize().divide(2).subtract(this.rfBinIndex)).multiply(this.binResolution).divide(1e3)));
//        }
//        catch (Exception e)
//        {
//            // TODO: handle exception
//        }
        return freqRf.multiply(1e6);
    }

    /**
     * calculate RF signal bin index.
     * @return RF signal bin index.
     */
    public MultiSiteLong getRfBinIndex() {
        return this.rfBinIndex;
    }

    /**
     * calculate LO bin index.
     * @return LO bin index.
     */
    public MultiSiteLong getLoBinIndex() {
        return this.loBinIndex;
    }

    /**
     * calculate IMAG bin index.
     * @return IMAG bin index.
     */
    public MultiSiteLong getImagBinIndex() {
        return this.imagBinIndex;
    }

    /**
     * calculate LO signal frequency.
     * @param freqExpected_MHz expected frequency in MHz.
     * @return LO signal frequency in unit Hz.
     */
    public MultiSiteDouble getLoFrequency(double freqExpected_MHz) {
        MultiSiteDouble freqLo=new MultiSiteDouble(0);
        for(int site:activeSites)
        {
            try
            {
                freqLo.set(site,freqExpected_MHz-(this.tx_spectrum_mW.getSize(site)/2-this.loBinIndex.getAsInt(site))*this.binResolution/1e3);
            }
            catch (Exception e)
            {
                // TODO: handle exception
            }
        }
//        try
//        {
//            freqLo.set(new MultiSiteDouble(freqExpected_MHz).subtract((this.tx_spectrum_mW.getSize().divide(2).subtract(this.loBinIndex)).multiply(this.binResolution).divide(1e3)));
//        }
//        catch (Exception e)
//        {
//            // TODO: handle exception
//        }
        return freqLo.multiply(1e6);
    }

    /**
     * calculate Imagine signal frequency.
     * @param freqExpected_MHz expected frequency in MHz.
     * @return Imagine signal frequency in unit Hz.
     */
    public MultiSiteDouble getImagFrequency(double freqExpected_MHz) {
        MultiSiteDouble freqImag=new MultiSiteDouble(0);
        for(int site:activeSites)
        {
            try
            {
                freqImag.set(site,freqExpected_MHz-(this.tx_spectrum_mW.getSize(site)/2-this.imagBinIndex.getAsInt(site))*this.binResolution/1e3);
            }
            catch (Exception e)
            {
                // TODO: handle exception
            }
        }
//        try
//        {
//            freqImag.set(new MultiSiteDouble(freqExpected_MHz).subtract((this.tx_spectrum_mW.getSize().divide(2).subtract(this.imagBinIndex)).multiply(this.binResolution).divide(1e3)));
//        } catch (Exception e)
//        {
//            // TODO: handle exception
//        }
        return freqImag.multiply(1e6);
    }

    /**
     * calculate RF to LO ratio.
     * @return RF to LO ratio in unit dB.
     */
    public MultiSiteDouble getLoLeakage() {
        return (this.powerRf.divide(this.powerLo)).log10().multiply(10);
    }

    /**
     * calculate RF to Imagine ratio.
     * @return RF to Imagine ratio in unit dB.
     */
     public MultiSiteDouble getImageRejection() {
        return  (this.powerRf.divide(this.powerImag)).log10().multiply(10);
    }

     /**
      * calculate SNR of RF Signal with specified bandwidth.
      * @return SNR in unit dB.
      */
      public MultiSiteDouble getRfSNR(double half_BandWidth) {
          MultiSiteDouble powerBW=new MultiSiteDouble();
          for(int site:activeSites) {
//              try {
//                  int half_BandWidthBin= (int) (half_BandWidth/this.binResolution);
//                  powerBW.set(site, this.tx_spectrum_mW.extractValues( this.rfBinIndex.subtract(half_BandWidthBin) , new MultiSiteLong(half_BandWidthBin*2+1)).sum().get(site));
//              }
//              catch (Exception e) {
//                  System.out.println("site "+site+" Spectrum abnormal, please check it!");
//              }
              try {
                  int half_BandWidthBin= (int) (half_BandWidth/this.binResolution);
                  powerBW.set(site, this.tx_spectrum_mW.get(site).extractValues( this.rfBinIndex.getAsInt(site)-half_BandWidthBin , half_BandWidthBin*2+1).sum());
              }
              catch (Exception e) {
                  System.out.println("site "+site+" Spectrum abnormal, please check it!");
              }
          }
          MultiSiteDouble powerNoise=new MultiSiteDouble(0);
          powerNoise.set(powerBW.subtract(this.powerRf));
          return  (this.powerRf.divide(powerNoise)).log10().multiply(10);
     }

}
