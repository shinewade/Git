package besLib.cal;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import xoc.dta.datatypes.MultiSiteBoolean;
import xoc.dta.datatypes.MultiSiteCharacterArray;
import xoc.dta.datatypes.MultiSiteLongArray;
import xoc.dta.datatypes.MultiSitePatternFailureList;
import xoc.dta.datatypes.MultiSiteString;
import xoc.dta.resultaccess.IDigInOutCyclePassFailResults;
import xoc.dta.resultaccess.IDigInOutResults;
import xoc.dta.setupaccess.IPatternCall;
import xoc.dta.workspace.IWorkspace;

public final class BesDFT_Debug{


    /**
     * Constructor function:
     * Convert MultiSiteLongArray ASCII data to MultiSiteString.
     * @param dataOutput The ASCII array long data.
     * @param stringLog  MultiSiteString result.
     */
    public MultiSiteString asciiToString(MultiSiteLongArray dataOutput ){
        MultiSiteString stringLog = new MultiSiteString();
        StringBuffer stringBuffer=new StringBuffer();
        char[] charTemp=new char[dataOutput.length()];
        MultiSiteCharacterArray characterArray=new MultiSiteCharacterArray(charTemp);

        for(int site:dataOutput.getActiveSites()) {
            for(int index=0;index<dataOutput.length();index++) {
                char tempChar=(char)(dataOutput.getElement(index).get(site).shortValue());
                characterArray.setElement(site, index,tempChar);
                if(tempChar!=0) {
                    stringBuffer.append(tempChar);
                }
            }
            stringLog.set(site, stringBuffer.toString());
            if(stringBuffer.length()>0)
            {
                stringBuffer.delete(0, stringBuffer.length()-1);
            }
        }

        return stringLog;
    }

    /**
     * Constructor function:
     * Write MultiSiteString data to text file and export it.
     * @param stringData The string data write to text file.
     * @param title      Topic description used for file naming.The content can contain only alphanumeric characters.
     */
    @SuppressWarnings("null")
    public void MultiSiteStringWriteToTextFile(MultiSiteString stringData, String title)
    {

        java.util.Date time = new java.util.Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");

        @SuppressWarnings("resource")
        BufferedWriter bw=null;
        try
        {
            bw=new BufferedWriter(new FileWriter(IWorkspace.getActiveProjectPath()+"_"+title.replace(" ", "_").replace(".", "")+".txt",true));
            System.out.println("Text File Has Been Generated In the Path : "+IWorkspace.getActiveProjectPath());
            bw.write("****************************************************************");
            bw.newLine();
            bw.write(title+" -- System Time: "+sdf.format(time).toString());
            bw.newLine();
            bw.write("****************************************************************");
            bw.newLine();
            bw.flush();
            for(int site:stringData.getActiveSites())
            {
                if(!stringData.get(site).isEmpty())
                {
                    bw.write("site["+site+"]: ");
                    bw.newLine();
                    bw.flush();
                    bw.write(stringData.get(site));
                    bw.newLine();
                    bw.newLine();
                    bw.newLine();
                    bw.newLine();
                    bw.newLine();
                    bw.newLine();
                    bw.flush();
                }
            }
        }
        catch (Exception e)
        {
            // TODO: handle exception
        }
        finally
        {
            try
            {
                 bw.close();
            }
            catch (Exception e2)
            {
                // TODO: handle exception
            }
        }
    }

    /**
     * Constructor function:
     * Convert long to hex string and write hex string to text file and export it.
     * @param rawDataArray The data convert to hex and write to text file.
     */
    @SuppressWarnings("null")
    public void hexDataWriteToTextFile(MultiSiteLongArray rawDataArray)
    {

        @SuppressWarnings("resource")
        BufferedWriter bw=null;
        try
        {
            bw=new BufferedWriter(new FileWriter(IWorkspace.getActiveProjectPath()+"ramrun_debug_information_log_hex_data.txt",true));
            System.out.println("Text File Has Been Generated In the Path : "+IWorkspace.getActiveProjectPath());
            bw.write("****************************************************************");
            bw.newLine();
            bw.write("Ramrun Debug Hex Data Log");
            bw.newLine();
            bw.write("****************************************************************");
            bw.newLine();
            bw.flush();
            for(int site:rawDataArray.getActiveSites())
            {
                if(rawDataArray.toMultiSiteWave().getSize(site)>0)
                {
                    bw.write("site["+site+"]: ");
                    bw.newLine();
                    bw.flush();
                    for(int index=0;index<rawDataArray.toMultiSiteWave().getSize(site);index++)
                    {
                        bw.write(Long.toHexString(rawDataArray.getElement(site, index)));
                        bw.write(" ");
                        if(index%50==0)
                        {
                            bw.newLine();
                        }
                        bw.flush();
                    }
                    bw.newLine();
                    bw.flush();
                }
            }
        }
        catch (Exception e)
        {
            // TODO: handle exception
        }
        finally
        {
            try
            {
                 bw.close();
            }
            catch (Exception e2)
            {
                // TODO: handle exception
            }
        }
    }

/**
 * Pattern fail cycle write to text.
 * @param DigInOutResults IDigInOutResults
 * @param logLevel 1:failcycle count; 2:failcycle count & failcycles log
 * @return Null
 */
//public void Println_Func_FailLog(IDigInOutCyclePassFailResults FailResults,int logLevel)
public void Println_Func_FailLog(IDigInOutResults DigInOutResults,int logLevel)

{
    IDigInOutCyclePassFailResults failCycle = DigInOutResults.cyclePassFail();
    List<IPatternCall> patternCallList = DigInOutResults.getPatternCalls();
    if(logLevel == 1)
    {
        for(int i=0; i<DigInOutResults.getPatternCalls().size(); i++)
        {
            System.out.println("Fail Count: "+failCycle.pattern(patternCallList.get(i)).getNumberOfFailedCycles());
        }
    }

    if(logLevel == 2)
    {
//		System.out.println(FailResults.getPatternFailures());
        for(int i=0; i<DigInOutResults.getPatternCalls().size(); i++)
        {
            Map<String, MultiSitePatternFailureList> fail_log = failCycle.pattern(patternCallList.get(i)).getPatternFailures();
            for(String pin:fail_log.keySet())
            {
                for(int site:fail_log.get(pin).getActiveSites())
                {
                    if(fail_log.get(pin).get(site).size()!=0)
                    {
                        System.out.println("site["+site+"]  failcycle count: "+fail_log.get(pin).get(site).size());
                        for(int index=0;index<fail_log.get(pin).get(site).size();index++)
                        {
                            System.out.println(fail_log.get(pin).get(site).get(index));
                        }
                        System.out.println();
                    }
                }
            }
        }
    }
    System.out.println();
}

/**
 * Pattern fail cycle write to text.
 * @param pattern_name    Used for fail log file naming
 * @param testSuiteName   Title of fail log content
 * @param FailResults IDigInOutCyclePassFailResults
 * @param FunResults      MultiSite Pattern pass fail results
 * @return Null
 */
@SuppressWarnings("null")
public void Func_FailLog_Write_To_File(String pattern_name, String testSuiteName, IDigInOutCyclePassFailResults FailResults, MultiSiteBoolean FunResults)
{
    boolean log_flag = false;

    for(int site:FunResults.getActiveSites())
    {
        if(FunResults.get(site).equals(false))
        {
            log_flag = true;
            break;
        }
    }

    Map<String, MultiSitePatternFailureList> fail_log = FailResults.getPatternFailures();
    @SuppressWarnings("resource")
    BufferedWriter bw=null;
    try
    {
        if(log_flag == true)
        {
            bw=new BufferedWriter(new FileWriter(IWorkspace.getActiveProjectPath()+pattern_name+"_fail_log.txt",true));//"/export/home/bestechnic3/BT1501"

            bw.write("***************************************");
            bw.newLine();
            bw.write(testSuiteName);
            bw.newLine();
            bw.write("***************************************");
            bw.newLine();
            bw.flush();

           for(String pin:fail_log.keySet())
           {
                for(int site:fail_log.get(pin).getActiveSites())
                {
                    if(fail_log.get(pin).get(site).size()!=0)
                    {
                        bw.write("site["+site+"] "+pin+" failcycle count: "+fail_log.get(pin).get(site).size());
                        bw.newLine();
                        bw.flush();
                        for(int index=0;index<fail_log.get(pin).get(site).size();index++)
                        {
                            bw.write(fail_log.get(pin).get(site).get(index).toString());
                            bw.newLine();
                            bw.flush();
                        }
                        bw.newLine();
                        bw.flush();
                    }
                }
           }
        }
    }
    catch (Exception e)
    {
        // TODO: handle exception
    }
    finally
    {
        try
        {
             bw.close();
        }
        catch (Exception e2)
        {
            // TODO: handle exception
        }
    }
}

}
