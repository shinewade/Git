package besLib.dsa;

import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupProtocolInterface;
import xoc.dsa.ISetupTransactionSeqDef;

public class BesDsa_Debug {
    protected IDeviceSetup ds;
    protected ISetupProtocolInterface[] paInterface;


    /**
     * Constructor function
     * @param ds an instance of IDeviceSetup interface
     */
    public BesDsa_Debug(IDeviceSetup ds)  {
        this.ds=ds;
        //PA
        this.paInterface=new ISetupProtocolInterface[1];
        this.paInterface[0] = this.ds.addProtocolInterface("I2C_8bit_BES","besLib.pa.I2C_8bit_BES");
        this.paInterface[0].addSignalRole("DATA", "I2C_SDA");
        this.paInterface[0].addSignalRole("CLK", "I2C_SCL");
    }

    public String vfim_Dcvi_Dps64(String dpsPin, double vforce) {
        ISetupDcVI[] dcvi=new ISetupDcVI[1];
        dcvi[0]=this.ds.addDcVI(dpsPin).setConnect(true).setDisconnect(true).setDisconnectModeHiz();
        dcvi[0].level().setIrange("500 mA").setVrange("6 V");
        dcvi[0].vforce("vf_"+dpsPin+"_"+String.valueOf(vforce).replace(".", "p")).setForceValue(vforce).setIrange("500 mA").setIclamp("500 mA");
        dcvi[0].imeas("im_"+dpsPin).setIrange("50 mA").setAverages(32).setWaitTime("45 ms").setRestoreIrange(true);

        this.ds.actionCall("");

        return "im_"+dpsPin;
    }

//    public String vfim_Dcvi_Dps64(String dpsPin, double vforce) {
//        ISetupDcVI[] dcvi=new ISetupDcVI[1];
//        dcvi[0]=this.ds.addDcVI(dpsPin).setConnect(true).setDisconnect(true).setDisconnectModeHiz();
//        dcvi[0].vforce("vf_"+dpsPin+"_"+String.valueOf(vforce)).setForceValue(vforce).setVrange("6 V").setIrange("500 mA").setIclamp("500 mA").setWaitTime("5 ms");
//        dcvi[0].imeas("im_"+dpsPin).setIrange("50 mA").setAverages(32).setWaitTime("45 ms").setRestoreIrange(true);
//
//        return "im_"+dpsPin;
//    }

//        ISetupDcVI dcVi_VCORE1=deviceSetup_VCORE_1.addDcVI("VCORE").setConnectMode(SetupConnectMode.highImpedance).setDisconnect(true).setDisconnectMode(SetupDisconnectMode.hiz);
//        dcVi_VCORE1.vmeas("Vm_VCORE").setWaitTime("2 ms").setAverages(4);

//        ISetupDcVI dcVi_VCORE2=deviceSetup_VCORE_2.addDcVI("VCORE").setConnectMode(SetupConnectMode.standard).setDisconnect(true).setDisconnectMode(SetupDisconnectMode.hiz);
//        dcVi_VCORE2.level().setIrange("100 mA").setVrange("6 V");
//        dcVi_VCORE2.iforce("If_100mA_VCORE").setForceValue("-100 mA").setVexpected("0.8 V").setVclampLow("0 V");
//        dcVi_VCORE2.vmeas("Vm_100mA_VCORE").setWaitTime("2 ms").setAverages(4);





    public void ramRun_Uart()  {

        ISetupTransactionSeqDef[] transDigSrc=new ISetupTransactionSeqDef[1];
        transDigSrc[0]= paInterface[0].addTransactionSequenceDef();
//        for(int i=0;i<handShake.size();i++)         {transDigSrc[0].addTransaction("writeUart", handShake.get(i));}


        //OpSeq
        ds.transactionSequenceCall(transDigSrc[0]);
    }


}
