package besLib.enumeration;

public class CMD_Mode {

    /**
     * Enum type for BES ram run communication CMD.
     */
    public enum cmd_Mode{
        HandShake_Non_Secure_Boot,
        Download_Program,
        Download_RET,
        Go_Program,
    }

}
