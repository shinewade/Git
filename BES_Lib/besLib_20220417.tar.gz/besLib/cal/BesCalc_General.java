package besLib.cal;

import xoc.dta.datatypes.MultiSiteLong;
import xoc.dta.datatypes.MultiSiteLongArray;
import xoc.dta.datatypes.dsp.MultiSiteWaveLong;

/**
 * This class is used for general function
 * @version V1.0
 * @author Weng Yongxin
 **/
public class BesCalc_General {

    /**
    * remove maximum minimum then calculate mean
    * @param rawData_Array Array in MultiSiteLongArray data type
    * @return Data value in MultiSiteLong data type
    */
   public MultiSiteLong meanCal(MultiSiteLongArray rawData_Array)
   {
       int[] activeSites = rawData_Array.getActiveSites();
       MultiSiteWaveLong Data_Wave_removeMax = new MultiSiteWaveLong();
       MultiSiteWaveLong Data_Wave_removeMin = new MultiSiteWaveLong();
       MultiSiteLong     Data = new MultiSiteLong();
       for(int site:activeSites)
       {
           Data_Wave_removeMax.set(site, rawData_Array.toMultiSiteWave().get(site).removeValues(rawData_Array.toMultiSiteWave().get(site).maxIndex(), 1));
           Data_Wave_removeMin.set(site, Data_Wave_removeMax.get(site).removeValues(Data_Wave_removeMax.get(site).minIndex(),1));

           Data.set(site, (long) Data_Wave_removeMin.get(site).mean());
       }
       return Data;
   }


//   /**
//    * Querying production related data.<br>
//    * @version 1.0
//    * @param testContext This interface enables you to access the test context of a measurement.
//    */
//   public  void getProductionInfo(ITestContext testContext) {
//       MultiSiteString waferX  =testContext.testProgram().variables().getString("STDF.X_COORD");
//       MultiSiteString waferY  =testContext.testProgram().variables().getString("STDF.Y_COORD");
//       MultiSiteString waferID =testContext.testProgram().variables().getString("STDF.WAFER_ID");
//
//       System.out.println("Die_X = "+waferX);
//       System.out.println("Die_Y = "+waferY);
//       System.out.println("Wafer_id = "+waferID);
//
//
//   }


}
