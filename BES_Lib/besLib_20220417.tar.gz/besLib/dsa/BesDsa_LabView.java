package besLib.dsa;

import java.util.ArrayList;

import besLib.cal.BesCalc_LabView;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupProtocolInterface;
import xoc.dsa.ISetupTransactionSeqDef;

/**
 * This class is used to generate BES LabView SSF file in Project
 * @version V1.0
 * @author Ronnie Li
 **/
public class BesDsa_LabView {

    private IDeviceSetup ds;
    private String DeviceName;
    private ArrayList<String> rawData_PMU_INTERN = new ArrayList<String>();
    private ArrayList<String> rawData_PMU        = new ArrayList<String>();
    private ArrayList<String> rawData_RF         = new ArrayList<String>();
    private ArrayList<String> rawData_ANA        = new ArrayList<String>();
    private ArrayList<String> rawData_RC         = new ArrayList<String>();
    private ArrayList<String> rawData_XTAL       = new ArrayList<String>();
    private ArrayList<String> rawData_EMMC       = new ArrayList<String>();
    private ArrayList<String> rawData_PCIE       = new ArrayList<String>();
    private ArrayList<String> rawData_DIGITAL    = new ArrayList<String>();
    private ArrayList<String> rawData_USB        = new ArrayList<String>();
    private ArrayList<String> rawData_CHARGER    = new ArrayList<String>();
    private ArrayList<String> rawData            = new ArrayList<String>();


    /**
     * Constructor
     * @param ds instance of IDeviceSetup interface
     */
    public BesDsa_LabView(IDeviceSetup ds) {
        this.ds=ds;
    }


    /**
     * LabView reg_config Text file generate TransactionSeq
     * @param fileName Text file name with qualified path in the project
     * @param labelName title in LabView reg_config Text file
     *
     */
    public void getRegListFromTextFile(String fileName,String labelName)  {
        if(fileName.contains(".txt")!=true){
            System.out.println("***************************************");
            System.out.println("** ERROR: filename suffix incorrect! **");
            System.out.println("***************************************");
        }

        if(fileName.contains("PMU_Reg"))
        {
            rawData_PMU_INTERN = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("PMU_INTERN_WRITE");
            rawData.addAll(rawData_PMU_INTERN);
        }
        else if(fileName.contains("P180"))
        {
            rawData_PMU = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("PMU_WRITE");
            rawData.addAll(rawData_PMU);
        }
        else if(fileName.contains("RF_Reg"))
        {
            rawData_RF = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("RF_WRITE");
            rawData.addAll(rawData_RF);
        }
        else if(fileName.contains("ANA_Reg"))
        {
            rawData_ANA = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("ANA_WRITE");
            rawData.addAll(rawData_ANA);
        }
        else if(fileName.contains("RC_Reg"))
        {
            rawData_RC = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("RC_WRITE");
            rawData.addAll(rawData_RC);
        }
        else if(fileName.contains("XTAL_Reg"))
        {
            rawData_XTAL = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("XTAL_WRITE");
            rawData.addAll(rawData_XTAL);
        }
        else if(fileName.contains("EMMC_Reg"))
        {
            rawData_EMMC = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("EMMC_WRITE");
            rawData.addAll(rawData_EMMC);
        }
        else if(fileName.contains("PCIE_Reg"))
        {
            rawData_PCIE = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("PCIE_WRITE");
            rawData.addAll(rawData_PCIE);
        }
        else if(fileName.contains("BT1000_Dig_Reg"))
        {
            rawData_DIGITAL = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("DIGITAL_WRITE");
            rawData.addAll(rawData_DIGITAL);
        }
        else if(fileName.contains("USB_Reg"))
        {
            rawData_USB = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("USB_WRITE");
            rawData.addAll(rawData_USB);
        }
        else if(fileName.contains("CHARGER_Reg"))
        {
            rawData_CHARGER = new BesCalc_LabView().getRegFromFile(fileName,labelName);
            rawData.add("CHARGER_WRITE");
            rawData.addAll(rawData_CHARGER);
        }
        else
        {
            System.out.println("*** ERROR : Unable to distinguish device type, please standardize file name. *** "+fileName);
        }
    }




    public void register_config_I2C()  {

        if(rawData.size() > 0)
        {
            //PA
            ISetupProtocolInterface[] paInterface=new ISetupProtocolInterface[1];
            paInterface[0] = this.ds.addProtocolInterface("I2C_BES", "besLib.pa.I2C_8bit_BES");
            paInterface[0].addSignalRole("CLK", "I2C_SCL");
            paInterface[0].addSignalRole("DATA", "I2C_SDA");
            ISetupTransactionSeqDef[] transDigSrc=new ISetupTransactionSeqDef[1];
            transDigSrc[0]= paInterface[0].addTransactionSequenceDef();
            for(int i=0; i<rawData.size(); i++)
            {
                if(rawData.get(i).contains("_WRITE"))
                {
                    DeviceName = rawData.get(i);
                }
                else
                {
                    if(rawData.get(i).contains("wait"))
                    {
                        int figure = 0;
                        int waitms = 0;
                        double temp = 0;
                        for(int j=0; j<rawData.get(i).length(); j++)
                        {
                            if(rawData.get(i).charAt(rawData.get(i).length()-j-1)>=0x30 && rawData.get(i).charAt(rawData.get(i).length()-j-1)<=0x39)
                            {
                                figure = rawData.get(i).charAt(rawData.get(i).length()-j-1)-0x30;
                                temp = j;
                                waitms = waitms+figure*Math.toIntExact(Math.round(Math.pow(10, temp)));
                            }
                        }
                        transDigSrc[0].addWait(waitms+" ms");
                    }
                    else
                    {
                        transDigSrc[0].addTransaction(DeviceName, rawData.get(i));
                    }
                }
            }
            //OpSeq
            this.ds.transactionSequenceCall(transDigSrc[0]);
        }
        else
        {
            System.out.println("*** ERROR : Valid data could not be retrieved from the text files ***");
        }
    }

}
