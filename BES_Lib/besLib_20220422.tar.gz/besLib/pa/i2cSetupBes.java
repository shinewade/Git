package besLib.pa;

import java.util.Map;
import java.util.Set;

import com.advantest.itee.tmapi.protocolaccess.DataField;
import com.advantest.itee.tmapi.protocolaccess.IProtocolSetup;
import com.advantest.itee.tmapi.protocolaccess.OperationType;
import com.advantest.itee.tmapi.protocolaccess.ProtocolAccess;
import com.advantest.itee.tmapi.protocolaccess.ProtocolInterfaceBase;
import com.advantest.itee.tmapi.protocolaccess.Transaction;
import com.advantest.itee.tmapi.protocolaccess.stdprotocols.I2C;

import xoc.dsa.DeviceSetupUncheckedException;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupPatternBlock.MatchMode;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.datatypes.BitSequence.BitOrder;

/**
 * This class can create I2C pattern for BES application
 * @version V1.0
 * @author wenju.sun
 * @param <VectorBlock>
 **/
public class i2cSetupBes extends ProtocolInterfaceBase{

    private IProtocolSetup protSetup;
    private I2C i2c;
    protected String scl="I2C_SCL";
    protected String sda="I2C_SDA";
    protected long slaveAddress;
    private Set<String> signals;
    private Map<String, Character> signalToDefaultSC;
    private final static char DEFAULT_STATE_CHAR = 'N';



    private final static String stateChar0 = "0";
    private final static String stateChar1 = "1";
    private final static String stateCharL = "L";
    private final static String stateCharH = "H";
    private final static String stateCharZ = "Z";
    private final static String stateCharF = "F";
    private final static String stateCharX = "X";
    private final static String stateCharP = "a";
    private final static String stateCharN = "Q";

    public i2cSetupBes(IDeviceSetup ds, IMeasurement measurement) {

        // Gets the protocol interface
        i2c=ProtocolAccess.getProtocolInterface(I2C.class);

        i2c.setBitOrder(BitOrder.LEFT_TO_RIGHT);

        // Starts creating transaction setups with this protocol interface.
        i2c.createSetup(ds, measurement);
        super.createSetup(ds, measurement);
        protSetup = getProtocolSetup();

        return;
    }

    /**
     * Specifies signals for the signal roles of the I2C Protocol Interface.
     *
     * @param scl  Signal for the role scl
     * @param sda  Signal for the role sda
     */
    public void setSignals(String scl, String sda) {
        if(scl != null){
            this.scl = scl;
        } else {
            throw new DeviceSetupUncheckedException("Signal Role 'scl' is a mandatory signal role. It cannot be set to null.");
        }
        if(sda != null){
            this.sda = sda;
        } else {
            throw new DeviceSetupUncheckedException("Signal Role 'sda' is a mandatory signal role. It cannot be set to null.");
        }
    }
    public void setSignals( String sda) {
        if(sda != null){
            this.sda = sda;
        } else {
            throw new DeviceSetupUncheckedException("Signal Role 'sda' is a mandatory signal role. It cannot be set to null.");
        }
    }

    public void transactionWithMathloop() {
        transactionSequenceBegin("matchloop");
        protSetup.matchLoopBegin(80, MatchMode.continueOnFail);
        protSetup.vectorBlock("matchLoop")
        .signal(scl).stateChar("PPP")
        .signal(sda).stateChar("LHL");
        protSetup.matchLoopEnd();
        transactionSequenceEnd();
    }
    public void testMatchloop() {
        Character myChar = 'X';
        protSetup.setDefaultStateChar(sda, myChar);
        protSetup.setDefaultStateChar(scl, myChar);
        double timeout = 10e-3;
        transactionSequenceBegin("matchloop");
        protSetup.vectorBlock("start")
        .signal(scl).stateCharRepeat("X",7)
        .signal(sda).stateCharRepeat("X",7);
//        protSetup.matchLoopBegin(timeout, MatchMode.continueOnFail);
        protSetup.matchLoopBegin(timeout, MatchMode.stopOnFail);
        protSetup.vectorBlock("matchLoop")
        .signal(scl).stateChar("aaa")
        .signal(sda).stateChar("HHL");
        protSetup.matchLoopEnd();
//        ((IProtocolSetup) protSetup.vectorBlock("end")).matchLoopEnd();//protSetup.matchLoopEnd().signal(scl).signal(scl).stateCharRepeat("a",1).signal(sda).stateCharRepeat("X",1);
        protSetup.vectorBlock("capture").signal(scl).stateCharRepeat("a", 625000)
        .signal(sda).stateCharRepeat("C",625000);

        transactionSequenceEnd();
    }

    /**
     * Starts condition of I2C.
     * @details sda sees a failing edge when scl is high.<br>
     * <pre>
     *      ________
     *  scl         |____
     *      ____
     *  sda     |________
     * </pre>
     *
     * Sends out a byte data on sda.
     * <pre>
     *         ____      ____      ____      ____      ____      ____      ____      ____
     *  scl __|    |____|    |____|    |____|    |____|    |____|    |____|    |____|    |__
     *        ______    ______    ______    ______    ______    ______    ______    ______
     *  sda _/ [7]  \__/ [6]  \__/ [5]  \__/ [4]  \__/ [3]  \__/ [2]  \__/ [1]  \__/ [0]  \_
     *  </pre>
     *  @param data
     *          a piece of data in byte. MSB first.
     *
     * Stops condition of I2C.
     * @details sda sees a rising edge when scl is high.
     * <pre>
     *          ________
     * scl ____|
     *              ____
     * sda ________|
     * </pre>
     */
//pmu
    public void pmuWrite(long address, long data) {
        slaveAddress=0x2e;
        transactionSequenceBegin("pmuWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void pmuWrite(long address, String dynamicWriteID) {
        slaveAddress=0x2e;
        transactionSequenceBegin("pmuDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void pmuRead(long address, String readID) {
        slaveAddress=0x2e;
        transactionSequenceBegin("pmuRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }

//pmu_INTERN
    public void pmu_INTERNWrite(long address, long data) {
        slaveAddress=0x4e;
        transactionSequenceBegin("pmuInternWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void pmu_INTERNWrite(long address, String dynamicWriteID) {
        slaveAddress=0x4e;
        transactionSequenceBegin("pmuInternDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void pmu_INTERNRead(long address, String readID) {
        slaveAddress=0x4e;
        transactionSequenceBegin("pmuInternRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//rf
    public void rfWrite(long address, long data) {
        slaveAddress=0x2c;
        transactionSequenceBegin("rfWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void rfWrite(long address, String dynamicWriteID) {
        slaveAddress=0x2c;
        transactionSequenceBegin("rfDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void rfRead(long address, String readID) {
        slaveAddress=0x2c;
        transactionSequenceBegin("rfRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//ana
    public void anaWrite(long address, long data) {
        slaveAddress=0x2a;
        transactionSequenceBegin("anaWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void anaWrite(long address, String dynamicWriteID) {
        slaveAddress=0x2a;
        transactionSequenceBegin("anaDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void anaRead(long address, String readID) {
        slaveAddress=0x2a;
        transactionSequenceBegin("anaRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//cdc
    public void cdcWrite(long address, long data) {
        slaveAddress=0x24;
        transactionSequenceBegin("cdcWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void cdcWrite(long address, String dynamicWriteID) {
        slaveAddress=0x24;
        transactionSequenceBegin("cdcDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void cdcRead(long address, String readID) {
        slaveAddress=0x24;
        transactionSequenceBegin("cdcRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//rc
    public void rcWrite(long address, long data) {
        slaveAddress=0x38;
        transactionSequenceBegin("rcWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void rcWrite(long address, String dynamicWriteID) {
        slaveAddress=0x38;
        transactionSequenceBegin("rcDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void rcRead(long address, String readID) {
        slaveAddress=0x38;
        transactionSequenceBegin("rcRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//xtal
    public void xtalWrite(long address, long data) {
        slaveAddress=0x36;
        transactionSequenceBegin("xtalWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void xtalWrite(long address, String dynamicWriteID) {
        slaveAddress=0x36;
        transactionSequenceBegin("xtalDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void xtalRead(long address, String readID) {
        slaveAddress=0x36;
        transactionSequenceBegin("xtalRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//emmc
    public void emmcWrite(long address, long data) {
        slaveAddress=0x32;
        transactionSequenceBegin("emmcWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void emmcWrite(long address, String dynamicWriteID) {
        slaveAddress=0x32;
        transactionSequenceBegin("emmcDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void emmcRead(long address, String readID) {
        slaveAddress=0x32;
        transactionSequenceBegin("emmcRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//pcie
    public void pcieWrite(long address, long data) {
        slaveAddress=0x20;
        transactionSequenceBegin("pcieWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void pcieWrite(long address, String dynamicWriteID) {
        slaveAddress=0x20;
        transactionSequenceBegin("pcieDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void pcieRead(long address, String readID) {
        slaveAddress=0x20;
        transactionSequenceBegin("pcieRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//usb
    public void usbWrite(long address, long data) {
        slaveAddress=0x30;
        transactionSequenceBegin("usbWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, data );
        transactionSequenceEnd();
    }
    public void usbWrite(long address, String dynamicWriteID) {
        slaveAddress=0x30;
        transactionSequenceBegin("usbDynamicWrite_"+"_0x"+Long.toHexString(address));
        write16Bits(address, dynamicWriteID, 0x00);
        transactionSequenceEnd();
    }
    public void usbRead(long address, String readID) {
        slaveAddress=0x30;
        transactionSequenceBegin("usbRead_"+"_0x"+Long.toHexString(address));
        read16Bits(address, readID);
        transactionSequenceEnd();
    }
//digital
    public void digitalWrite(long address, long data) {
        slaveAddress=0x22;
        transactionSequenceBegin("digitalWrite_"+"_0x"+Long.toHexString(address));
        write32Bits(address, data );
        transactionSequenceEnd();
    }
    public void digitalWrite(long address, String dynamicWriteID) {
        slaveAddress=0x22;
        transactionSequenceBegin("digitalDynamicWrite_"+"_0x"+Long.toHexString(address));
        write32Bits(address, dynamicWriteID, 0x00 );
        transactionSequenceEnd();
    }
    public void digitalRead(long address, String readID) {
        slaveAddress=0x22;
        transactionSequenceBegin("digitalRead_"+"_0x"+Long.toHexString(address));
        read32Bits(address, readID);
        transactionSequenceEnd();
    }

    public void write16Bits(long address,long data) {

        protSetup.vectorBlock("WRITE"+"_0x"+Long.toHexString(address)+"_idle_sta1").signal(scl)
        .stateChar("1111").signal(sda).stateChar("1110");                                                    //start Condition

        protSetup.vectorBlock("device address_ACK").signal(sda).stateChar(new DataFieldWrite(slaveAddress)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("address_ACK").signal(sda).stateChar(new DataFieldWrite(address)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("data").signal(sda).stateChar(new DataFieldWrite16Bits(data)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 18);

        protSetup.vectorBlock("stp").signal(sda).stateChar("0001")
        .signal(scl).stateChar("0011");

        protSetup.vectorBlock("stpRep2").signal(sda).stateCharRepeat("1", 10)
        .signal(scl).stateCharRepeat("1", 10);

    }

    public void write16Bits(long address,String dynamicWriteID,long data ) {

        protSetup.vectorBlock("dynamicWrite"+"_0x"+Long.toHexString(address)+"_idle_sta1").signal(scl)
        .stateChar("1111").signal(sda).stateChar("1110");                                                    //start Condition

        protSetup.vectorBlock("device address_ACK").signal(sda).stateChar(new DataFieldWrite(slaveAddress)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("address_ACK").signal(sda).stateChar(new DataFieldWrite(address)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("dynamicWrite_data").signal(sda).stateChar(new DataFieldWrite16Bits(dynamicWriteID,data)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 18);

        protSetup.vectorBlock("stp").signal(sda).stateChar("0001")
        .signal(scl).stateChar("0011");

        protSetup.vectorBlock("stpRep2").signal(sda).stateCharRepeat("1", 10)
        .signal(scl).stateCharRepeat("1", 10);

    }
    /**
     * Support sends out a byte data at runtime or not on sda. According to the
     * input parameter's type to choice which method would like to call.
     *
     * @param data
     *          If the input data's type is long then send static data.
     *          If the type is String that call the dynamic-write operation.
     */
    @Transaction
    public void pmuWrite(long address,Object data) {
        if (data instanceof Long) {
            pmuWrite(((Long) address).longValue(),((Long) data).longValue());
        }  else if (data instanceof String) {
            pmuWrite(((Long) address).longValue(),data);
        }else {
            throw new DeviceSetupUncheckedException("Unsupported parameter type in pmuWrite()");
        }
    }


    public void read16Bits(long address,String readID ) {

        protSetup.vectorBlock("READ_"+readID+"_idle_sta1").signal(scl)
        .stateChar("1111").signal(sda).stateChar("1110");                                                    //start Condition

        protSetup.vectorBlock("device address_ACK").signal(sda).stateChar(new DataFieldWrite(slaveAddress)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("address_ACK").signal(sda).stateChar(new DataFieldWrite(address)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("sta2").signal(sda).stateChar("10")
        .signal(scl).stateChar("11");

        protSetup.vectorBlock("device address_ACK").signal(sda).stateChar(new DataFieldWrite(slaveAddress+1)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("read_data").signal(sda).stateChar(new DataFieldRead(readID)).stateChar("1")
        .signal(scl).stateCharRepeat("a", 18);

        protSetup.vectorBlock("stp").signal(sda).stateChar("001")
        .signal(scl).stateChar("011");

        protSetup.vectorBlock("stpRep2").signal(sda).stateCharRepeat("1", 10)
        .signal(scl).stateCharRepeat("1", 10);

    }

//digital
    public void write32Bits(long address,long data ) {

        protSetup.vectorBlock("Write"+"_0x"+Long.toHexString(address)+"_idle_sta1").signal(scl)
        .stateChar("1111").signal(sda).stateChar("1110");                                                    //start Condition

        protSetup.vectorBlock("device address_ACK").signal(sda).stateChar(new DataFieldWrite(slaveAddress)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("address_ACK").signal(sda).stateChar(new DataFieldWrite32Bits(address)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 36);

        protSetup.vectorBlock("rsta1").signal(sda).stateChar("110")
        .signal(scl).stateChar("011");

        protSetup.vectorBlock("Write_data").signal(sda).stateChar(new DataFieldWrite32Bits(data)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 36);

        protSetup.vectorBlock("stp").signal(sda).stateChar("001")
        .signal(scl).stateChar("011");

        protSetup.vectorBlock("stpRep2").signal(sda).stateCharRepeat("1", 10)
        .signal(scl).stateCharRepeat("1", 10);

    }
    public void write32Bits(long address,String dynamicWriteID,long data ) {

        protSetup.vectorBlock("dynamicWrite"+"_0x"+Long.toHexString(address)+"_idle_sta1").signal(scl)
        .stateChar("1111").signal(sda).stateChar("1110");                                                    //start Condition

        protSetup.vectorBlock("device address_ACK").signal(sda).stateChar(new DataFieldWrite(slaveAddress)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("address_ACK").signal(sda).stateChar(new DataFieldWrite32Bits(address)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 36);

        protSetup.vectorBlock("rsta1").signal(sda).stateChar("110")
        .signal(scl).stateChar("011");

        protSetup.vectorBlock("dynamicWrite_data").signal(sda).stateChar(new DataFieldWrite32Bits(dynamicWriteID,data)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 36);

        protSetup.vectorBlock("stp").signal(sda).stateChar("001")
        .signal(scl).stateChar("011");

        protSetup.vectorBlock("stpRep2").signal(sda).stateCharRepeat("1", 10)
        .signal(scl).stateCharRepeat("1", 10);

    }
    /**
     * Support sends out a byte data at runtime or not on sda. According to the
     * input parameter's type to choice which method would like to call.
     *
     * @param data
     *          If the input data's type is long then send static data.
     *          If the type is String that call the dynamic-write operation.
     */
    @Transaction
    public void write32Bits(long address,Object data) {
        if (data instanceof Long) {
            digitalWrite(((Long) address).longValue(),((Long) data).longValue());
        }  else if (data instanceof String) {
            write32Bits(((Long) address).longValue(),data);
        }else {
            throw new DeviceSetupUncheckedException("Unsupported parameter type in digitalWrite()");
        }
    }

    public void read32Bits(long address,String readID ) {
        protSetup.vectorBlock("READ_32bits"+"_0x"+Long.toHexString(address)+"_idle_sta1").signal(scl)
        .stateChar("1111").signal(sda).stateChar("1"+"1"+"10");                                                    //start Condition

        protSetup.vectorBlock("device address_ACK").signal(sda).stateChar(new DataFieldWrite(slaveAddress)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("address_ACK").signal(sda).stateChar(new DataFieldWrite32Bits(address)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 36);

        protSetup.vectorBlock("rsta1").signal(sda).stateChar("110")
        .signal(scl).stateChar("011");

        protSetup.vectorBlock("device address_ACK").signal(sda).stateChar(new DataFieldWrite(slaveAddress+1)).stateChar("X")
        .signal(scl).stateCharRepeat("a", 9);

        protSetup.vectorBlock("read_data").signal(sda).stateChar(new DataFieldRead32Bits(readID)).stateChar("1")
        .signal(scl).stateCharRepeat("a", 36);

        protSetup.vectorBlock("stp").signal(sda).stateChar("001")
        .signal(scl).stateChar("011");

        protSetup.vectorBlock("stpRep2").signal(sda).stateCharRepeat("1", 10)
        .signal(scl).stateCharRepeat("1", 10);

    }

    private final static String LAYOUT = "[7-0]";//MSB first
//  private final static String LAYOUT = "[0-7]";//LSB first

    class DataFieldWrite extends DataField{

        public long data = 0;
        public String dynamicWriteID;

        public DataFieldWrite(long data) {
            super(OperationType.WRITE);
            this.setData(data);
        }

        public DataFieldWrite(String dynamicWriteID, long data) {
            super(OperationType.DYNAMIC_WRITE);
            this.setData(data);
            super.setId(dynamicWriteID);
        }

        @Override
        public String getDataLayout() {
            return LAYOUT;
        }
    }
    class DataFieldWrite16Bits extends DataField{

        public long data = 0;
        public String dynamicWriteID;

        public DataFieldWrite16Bits(long data) {
            super(OperationType.WRITE);
            this.setData(data);
        }

        public DataFieldWrite16Bits(String dynamicWriteID, long data) {
            super(OperationType.DYNAMIC_WRITE);
            super.setData(data);
            super.setId(dynamicWriteID);
            this.data = data;
            this.dynamicWriteID = dynamicWriteID;
        }

        @Override
        public String getDataLayout() {
            return "[15-8]X{1}[7-0]";
        }
    }
    class DataFieldWrite32Bits extends DataField{

        public long data = 0;
        public String dynamicWriteID;

        public DataFieldWrite32Bits(long data) {
            super(OperationType.WRITE);
            this.setData(data);
        }

        public DataFieldWrite32Bits(String dynamicWriteID, long data) {
            super(OperationType.DYNAMIC_WRITE);
            super.setData(data);
            super.setId(dynamicWriteID);
            this.data = data;
            this.dynamicWriteID = dynamicWriteID;
        }

        @Override
        public String getDataLayout() {
            return "[31-24]X{1}[23-16]X{1}[15-8]X{1}[7-0]";
        }
    }


    class DataFieldRead extends DataField{

        protected DataFieldRead(String dataSda) {
            super(OperationType.READ);
            this.setId(dataSda);
        }

        @Override
        public String getDataLayout() {
          return "[0-7]0{1}[8-15]";
        }
    }
    class DataFieldRead32Bits extends DataField{

        protected DataFieldRead32Bits(String dataSda) {
            super(OperationType.READ);
            this.setId(dataSda);
        }

        @Override
        public String getDataLayout() {
            return "[0-7]0{1}[8-15]0{1}[16-23]0{1}[24-31]";
        }
    }

}
