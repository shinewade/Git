package besLib.generalTestMethod;

import java.util.ArrayList;
import java.util.List;

import xoc.dta.TestMethod;
import xoc.dta.annotations.Out;
import xoc.dta.datatypes.MultiSiteLong;

public class GetBinPassFlag extends TestMethod {
    @Out public static MultiSiteLong bin2PassFlag=new MultiSiteLong(-1);
    @Out public static MultiSiteLong bin3PassFlag=new MultiSiteLong(-1);
    @Out public static MultiSiteLong bin4PassFlag=new MultiSiteLong(-1);
    public static List<Integer>[] softBinList;

    @SuppressWarnings("unchecked")
    @Override
    public void execute() {
        int siteNum=context.getActiveSites().length;
        softBinList=new List[siteNum];
        List<Integer>[] SoftBinList_bin2_Union=new List[siteNum];
        List<Integer>[] SoftBinList_bin3_Union=new List[siteNum];
        List<Integer>[] SoftBinList_bin4_Union=new List[siteNum];

        for (int site : context.getActiveSites()) {
            softBinList[site-1] = context.binning().getBinList(site, true);

            //union
            SoftBinList_bin2_Union[site-1]=new ArrayList<Integer>();
            SoftBinList_bin3_Union[site-1]=new ArrayList<Integer>();
            SoftBinList_bin4_Union[site-1]=new ArrayList<Integer>();
            SoftBinList_bin2_Union[site-1].addAll(PassBinGrade.sbin_Map.get(2));
            SoftBinList_bin3_Union[site-1].addAll(PassBinGrade.sbin_Map.get(3));
            SoftBinList_bin4_Union[site-1].addAll(PassBinGrade.sbin_Map.get(4));

            SoftBinList_bin2_Union[site-1].retainAll(softBinList[site-1]);
            SoftBinList_bin3_Union[site-1].retainAll(softBinList[site-1]);
            SoftBinList_bin4_Union[site-1].retainAll(softBinList[site-1]);

            bin2PassFlag.set(site, SoftBinList_bin2_Union[site-1].size()==0 ? -1:1);
            bin3PassFlag.set(site, SoftBinList_bin3_Union[site-1].size()==0 ? -1:1);
            bin4PassFlag.set(site, SoftBinList_bin4_Union[site-1].size()==0 ? -1:1);

//            String testSuiteName_Qualified=context.getTestSuiteName();
//            String testSuiteName=testSuiteName_Qualified.substring(1+testSuiteName_Qualified.lastIndexOf("."));
//            println("**********"+testSuiteName+"**********");
//            println("site= "+site+" CurrentBinList= "+softBinList[site-1].toString());
//            println("site= "+site+" SoftBinList_bin2_Union= "+SoftBinList_bin2_Union[site-1].toString());
//            println("site= "+site+" SoftBinList_bin3_Union= "+SoftBinList_bin3_Union[site-1].toString());
//            println("site= "+site+" SoftBinList_bin4_Union= "+SoftBinList_bin4_Union[site-1].toString());
//            println("site= "+site+" bin2PassFlag= "+bin2PassFlag.get(site));
//            println("site= "+site+" bin3PassFlag= "+bin3PassFlag.get(site));
//            println("site= "+site+" bin4PassFlag= "+bin4PassFlag.get(site));
//            println();
        }

    }

}
