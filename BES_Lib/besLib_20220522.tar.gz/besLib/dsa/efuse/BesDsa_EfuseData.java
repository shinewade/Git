package besLib.dsa.efuse;

import xoc.dta.datatypes.MultiSiteBoolean;
import xoc.dta.datatypes.MultiSiteLong;

public interface BesDsa_EfuseData  {
    /**
     * Process e-fuse data of address 0 for Writing
     * @return Processed data for e-fuse 0
     */
    public MultiSiteLong dataPreprocessing_Efuse0();

    /**
     * Process e-fuse data of address 1 for Writing
     * @return Processed data for e-fuse 1
     */
    public MultiSiteLong dataPreprocessing_Efuse1();

    /**
     * Process e-fuse data of address 2 for Writing
     * @return Processed data for e-fuse 2
     */
    public MultiSiteLong dataPreprocessing_Efuse2();

    /**
     * Process e-fuse data of address 3 for Writing
     * @return Processed data for e-fuse 3
     */
    public MultiSiteLong dataPreprocessing_Efuse3();

    /**
     * Process e-fuse data of address 4 for Writing
     * @return Processed data for e-fuse 4
     */
    public MultiSiteLong dataPreprocessing_Efuse4();

    /**
     * Process e-fuse data of address 5 for Writing
     * @return Processed data for e-fuse 5
     */
    public MultiSiteLong dataPreprocessing_Efuse5();

    /**
     * Process e-fuse data of address 6 for Writing
     * @return Processed data for e-fuse 6
     */
    public MultiSiteLong dataPreprocessing_Efuse6();

    /**
     * Process e-fuse data of address 7 for Writing
     * @return Processed data for e-fuse 7
     */
    public MultiSiteLong dataPreprocessing_Efuse7();

    /**
     * Process e-fuse data of address 8 for Writing
     * @return Processed data for e-fuse 8
     */
    public MultiSiteLong dataPreprocessing_Efuse8();

    /**
     * Process e-fuse data of address 9 for Writing
     * @return Processed data for e-fuse 9
     */
    public MultiSiteLong dataPreprocessing_Efuse9();

    /**
     * Process e-fuse data of address 10 for Writing
     * @return Processed data for e-fuse 10
     */
    public MultiSiteLong dataPreprocessing_Efuse10();

    /**
     * Process e-fuse data of address 11 for Writing
     * @return Processed data for e-fuse 11
     */
    public MultiSiteLong dataPreprocessing_Efuse11();

    /**
     * Process e-fuse data of address 12 for Writing
     * @return Processed data for e-fuse 12
     */
    public MultiSiteLong dataPreprocessing_Efuse12();

    /**
     * Process e-fuse data of address 13 for Writing
     * @return Processed data for e-fuse 13
     */
    public MultiSiteLong dataPreprocessing_Efuse13();

    /**
     * Process e-fuse data of address 14 for Writing
     * @return Processed data for e-fuse 14
     */
    public MultiSiteLong dataPreprocessing_Efuse14();

    /**
     * Process e-fuse data of address 15 for Writing
     * @return Processed data for e-fuse 15
     */
    public MultiSiteLong dataPreprocessing_Efuse15();

    /**
     * Get MultiSiteBoolean flag to decide whether write e-fuse per site
     *
     * @param readData_Pre read e-fuse data before writing
     * @param multiSiteEfuseFlag  MultiSiteBoolean value same to the write flag set in test suite
     * @return MultiSiteBoolean MultiSiteBoolean flag to decide whether write e-fuse per site
     */
    public MultiSiteBoolean efuseWriteFlag(MultiSiteLong readData_Pre, MultiSiteBoolean multiSiteEfuseFlag );

    /**
     * Judge whether e-fuse has been written before (QA) to decide if need to run measurement object of writing e-fuse.
     * @param multiSiteEfuseFlag MultiSiteBoolean flag to decide whether write e-fuse per site
     * @return boolean flag to judge whether write e-fuse
     */
    public boolean efuseSkipFlag(MultiSiteBoolean multiSiteEfuseFlag );

    public MultiSiteLong dataEvaluation(int efuseAddr, MultiSiteLong writeData_Efuse, MultiSiteBoolean multiSiteEfuseFlag, MultiSiteLong readData_Pre, MultiSiteLong readData_Post);




}
