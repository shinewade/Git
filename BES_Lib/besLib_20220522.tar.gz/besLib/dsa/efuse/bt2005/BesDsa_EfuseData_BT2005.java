package besLib.dsa.efuse.bt2005;

import besLib.dsa.efuse.BesDsa_EfuseData;
import bt2005_tml.global.StaticFields;
import xoc.dta.datatypes.MultiSiteBoolean;
import xoc.dta.datatypes.MultiSiteLong;

public class BesDsa_EfuseData_BT2005  implements BesDsa_EfuseData{

    @Override
    public MultiSiteLong dataPreprocessing_Efuse0() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse1() {
        return new MultiSiteLong(0x8003);
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse2() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse3() {
        MultiSiteLong writeData_Efuse=new MultiSiteLong(0);
        writeData_Efuse.set(StaticFields.VSENSE_3P2V);
        for(int site: StaticFields.VSENSE_3P2V.getActiveSites()) {
            if(writeData_Efuse.get(site)<14400 || writeData_Efuse.get(site)>15500) {
                writeData_Efuse.set(site, 0);
            }
        }
        return writeData_Efuse;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse4() {
        MultiSiteLong writeData_Efuse=new MultiSiteLong(0);
        writeData_Efuse.set(StaticFields.VSENSE_4P2V);
        for(int site: StaticFields.VSENSE_4P2V.getActiveSites()) {
            if(writeData_Efuse.get(site)<19000 || writeData_Efuse.get(site)>20500) {
                writeData_Efuse.set(site, 0);
            }
        }
        return writeData_Efuse;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse5() {
        MultiSiteLong writeData_Efuse=new MultiSiteLong(0);
        writeData_Efuse.set( (StaticFields.efuse_DirectionBit_H.leftShift(15)).and(0x8000) );
        return writeData_Efuse;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse6() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse7() {
        MultiSiteLong writeData_Efuse=new MultiSiteLong(0);
        //Efuse PWR CAL FreqL
        MultiSiteLong temp=new MultiSiteLong(0);
        temp.set( StaticFields.efuse_ABS_CalShift_L.or(StaticFields.efuse_ABS_CalShift_L.leftShift(3)) );
        temp.set(temp.and(0xf).leftShift(5).add(writeData_Efuse));
        writeData_Efuse.set(temp);

        //Efuse PWR CAL FreqM
        temp.set(0);
        temp.set( StaticFields.efuse_ABS_CalShift_M.or(StaticFields.efuse_ABS_CalShift_M.leftShift(3)) );
        temp.set(temp.and(0xf).leftShift(9).add(writeData_Efuse));
        writeData_Efuse.set(temp);

        //Efuse PWR CAL FreqH
        temp.set(0);
        temp.set( StaticFields.efuse_ABS_CalShift_H);
        temp.set( temp.and(0x7).leftShift(13).add(writeData_Efuse) );
        writeData_Efuse.set(temp);

        //BT dlyCap
        writeData_Efuse.set(StaticFields.lBt_CalValue_0x28.or(1<<4).and(0x1f).add(writeData_Efuse));
        return writeData_Efuse;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse8() {
        MultiSiteLong writeData_Efuse=new MultiSiteLong(0);
        //DCDC Calibration VCORE
        MultiSiteLong temp=new MultiSiteLong(0);
        temp.set( StaticFields.cal_Shift_Vcore.abs().and(0x1f).add(writeData_Efuse) );
        writeData_Efuse.set(temp);
        //Direction
        temp.set(0);
        for(int site:StaticFields.cal_Shift_Vcore.getActiveSites()) {
            temp.set(site, StaticFields.cal_Shift_Vcore.get(site)<=0?1:0);
            temp.set(site, (temp.get(site)<<5)+writeData_Efuse.get(site));
        }
        writeData_Efuse.set(temp);

        //DCDC Calibration VANA
        temp.set(0);
        temp.set( StaticFields.cal_Shift_Vana.abs().and(0xf).leftShift(6).add(writeData_Efuse) );
        writeData_Efuse.set(temp);
        //Direction
        temp.set(0);
        for(int site:StaticFields.cal_Shift_Vana.getActiveSites()) {
            temp.set(site, StaticFields.cal_Shift_Vana.get(site)<=0?1:0);
            temp.set(site, (temp.get(site)<<10)+writeData_Efuse.get(site));
        }
        writeData_Efuse.set(temp);

        //DCDC Calibration VCODEC
        temp.set(0);
        temp.set( StaticFields.cal_Shift_Vcodec.abs().and(0xf).leftShift(11).add(writeData_Efuse) );
        writeData_Efuse.set(temp);
        //Direction
        temp.set(0);
        for(int site:StaticFields.cal_Shift_Vcodec.getActiveSites()) {
            temp.set(site, StaticFields.cal_Shift_Vcodec.get(site)<=0?1:0);
            temp.set(site, (temp.get(site)<<15)+writeData_Efuse.get(site));
        }
        writeData_Efuse.set(temp);
        return writeData_Efuse;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse9() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse10() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse11() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse12() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse13() {
        MultiSiteLong writeData_Efuse=new MultiSiteLong(0);
        writeData_Efuse.set(StaticFields.temperatureSensor);
        for(int site: StaticFields.temperatureSensor.getActiveSites()) {
            if(writeData_Efuse.get(site)<20100 || writeData_Efuse.get(site)>23100) {
                writeData_Efuse.set(site, 0);
            }
        }
        return writeData_Efuse;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse14() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteLong dataPreprocessing_Efuse15() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public MultiSiteBoolean efuseWriteFlag(MultiSiteLong readData_Pre, MultiSiteBoolean multiSiteEfuseFlag ) {
        for(int site :readData_Pre.getActiveSites()) {
            if(multiSiteEfuseFlag.get(site) && readData_Pre.get(site)==0 ) {
                multiSiteEfuseFlag.set(site, true);
            }
            else {
                multiSiteEfuseFlag.set(site, false);
            }
        }
        return multiSiteEfuseFlag;
    }

    @Override
    public boolean efuseSkipFlag(MultiSiteBoolean multiSiteEfuseFlag ) {
        boolean skip_Efuse=true;
        for(int site :multiSiteEfuseFlag.getActiveSites()) {
            if(multiSiteEfuseFlag.get(site)) {
                skip_Efuse=false;
            }
        }
        return skip_Efuse;
    }

    @Override
    public MultiSiteLong dataEvaluation(int efuseAddr,MultiSiteLong writeData_Efuse, MultiSiteBoolean multiSiteEfuseFlag, MultiSiteLong readData_Pre, MultiSiteLong readData_Post) {
        MultiSiteLong passFlag=new MultiSiteLong(0);
        for(int site :writeData_Efuse.getActiveSites()) {
            if(multiSiteEfuseFlag.get(site)) {//FT
                if(readData_Post.get(site).equals(writeData_Efuse.get(site)) && readData_Post.get(site)!=0x0 && readData_Post.get(site)!=0xffff) {
                    passFlag.set(site, 1);
                }
            }
            else {//QA or FT_RT which address has been fused
                switch (efuseAddr) {
                case 0:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 1:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 2:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 3:
                    if(Math.abs( readData_Pre.get(site)-writeData_Efuse.get(site))<100) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 4:
                    if(Math.abs( readData_Pre.get(site)-writeData_Efuse.get(site))<100) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 5:

                    if(Math.abs((Math.abs(StaticFields.cal_Shift_Vcore.get(site)) & 0x1f)-(readData_Pre.get(site)&0x1f))<5        &&
                       Math.abs((Math.abs(StaticFields.cal_Shift_Vana.get(site)) & 0xf)-((readData_Pre.get(site)>>6) & 0xf))<5    &&
                       Math.abs((Math.abs(StaticFields.cal_Shift_Vcodec.get(site)) & 0xf)-((readData_Pre.get(site)>>11) & 0xf))<5    )
                    {
                        passFlag.set(site, 1);
                    }
                    break;
                case 6:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 7:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 8:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 9:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 10:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 11:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 12:
                    if(readData_Pre.get(site).equals(writeData_Efuse.get(site))) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 13:
                    if(Math.abs( readData_Pre.get(site)-writeData_Efuse.get(site))<400) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 14:
                    if(Math.abs( readData_Pre.get(site)-writeData_Efuse.get(site))<100) {
                        passFlag.set(site, 1);
                    }
                    break;
                case 15:
                    MultiSiteLong Wifi_0x37_addr = new MultiSiteLong();
                    MultiSiteLong Wifi_0x34_addr = new MultiSiteLong();
                    MultiSiteLong Wifi_0x37_w = new MultiSiteLong();
                    MultiSiteLong Wifi_0x34_w = new MultiSiteLong();
                    Wifi_0x37_addr.set(site, (readData_Pre.get(site)& 0x1f));
                    Wifi_0x34_addr.set(site, ((readData_Pre.get(site)>>5) & 0x1f));    //Wifi_0x34_addr.set(site, ((readData_Pre.get(site)>>8) & 0xff));
                    Wifi_0x37_w.set(site, (writeData_Efuse.get(site)& 0x1f));
                    Wifi_0x34_w.set(site, ((writeData_Efuse.get(site)>>5) & 0x1f));
                    long delta1=Math.abs(Wifi_0x37_addr.get(site)-Wifi_0x37_w.get(site));// diff <= 1 step
                    long delta2=Math.abs(Wifi_0x34_addr.get(site)-Wifi_0x34_w.get(site));// diff <= 1 step

//                    if(Math.abs(Wifi_0x37_addr.get(site)-Wifi_0x37_w.get(site)) <= 1 && Math.abs(Wifi_0x34_addr.get(site)-Wifi_0x34_w.get(site)) <=1 && ((readData_Pre.get(site)&0x8000) == 0x8000) ) { // diff <= 1 step
//                            if ((delta1 & delta2) ==1) { // diff <= 1 step
                    if((readData_Pre.get(site)&0x0400) == 0x0400 ) { //diff <= 2 step
                        if (delta1==2) {
                            if(delta2 ==0 ){
                                passFlag.set(site,1);
                            }
                            else {
                                passFlag.set(site,0);
                            }
                        }
                        else if (delta1==1){
                            if(delta2 <= 1){// diff <= 2 step
                                passFlag.set(site,1);
                            }
                            else {
                                passFlag.set(site,0);
                            }
                        }
                        else if (delta1==0){
                            if(delta2 <= 2){// diff <= 2 step
                                passFlag.set(site,1);
                            }
                            else {
                                passFlag.set(site,0);
                            }
                        }
                        else {
                            passFlag.set(site,0);
                        }
                    }
                    else {
                        passFlag.set(site,0);
                    }
                    break;

                default:
                    break;
                }

            }

        }
        return passFlag;
    }









}
