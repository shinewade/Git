package besLib.dsa.efuse.bt2005;

import com.advantest.itee.tmapi.protocolaccess.ProtocolAccess;

import besLib.dsa.efuse.BesDsa_Efuse;
import besLib.pa.BesPA_I2C;
import besLib.pa.BesPA_I2C.BesI2cAddrType;
import besLib.pa.BesPA_I2C.I2cRegAddrBits;
import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dta.datatypes.MultiSiteBoolean;
import xoc.dta.datatypes.MultiSiteLong;
import xoc.dta.measurement.IMeasurement;

public class BesDsa_Efuse_BT2005  extends BesDsa_Efuse{

    private String I2C_SCL="I2C_SCL";
    private String I2C_SDA="I2C_SDA";

    @Override
    public void genDsa_ReadEfuse(int efuseAddr, IMeasurement measurement, String spec, String prefix) {
        // TODO Auto-generated method stub
        IDeviceSetup ds1=DeviceSetupFactory.createInstance(prefix);
        ds1.importSpec(spec);
        BesPA_I2C i2c=new BesPA_I2C(ds1, measurement, I2cRegAddrBits.RegAddr_16Bits);
        i2c.setSignals(I2C_SCL, I2C_SDA);

        i2c.transactionSequenceBegin("BT2005_ReadEfuse_"+efuseAddr);
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0008);                //open e-fuse clock Enable,read mode
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0018);                //open function turn on
            i2c.waitTime(0.25e6);
            i2c.write(BesI2cAddrType.PMU, 0xb5, efuseAddr<<4 ) ; //write address[9:4] (efuseAddr<<4)&0x3f0
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0038);                //read trigger enable
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0018);                //read trigger disable
            i2c.waitTime(0.25e6);
            i2c.read( BesI2cAddrType.PMU, 0xbd, "efuse_Hihg");          //efuse_data_out_hi[15:0]
            i2c.read( BesI2cAddrType.PMU, 0xbe, "efuse_Low");           //efuse_data_out_low[15:0]
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0018);                //function turn off
            i2c.write(BesI2cAddrType.PMU, 0xb5, 0x0000);                //clear data[14:10],address[9:4]
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0000);                //close clock
        i2c.transactionSequenceEnd();
        measurement.setSetups(ds1);
    }

    @Override
    public void genDsa_WriteEfuse(IMeasurement measurement, String spec, String prefix) {
        // TODO Auto-generated method stub
        IDeviceSetup ds1=DeviceSetupFactory.createInstance(prefix);
        ds1.importSpec(spec);
        BesPA_I2C i2c=new BesPA_I2C(ds1, measurement, I2cRegAddrBits.RegAddr_16Bits);
        i2c.setSignals(I2C_SCL, I2C_SDA);

        i2c.transactionSequenceBegin("BT2005_Dyn_WriteEfuse");
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0009);//open e-fuse clock Enable,pgm_mode selected
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0019);//open function turn on
            for(int bitIndex=0; bitIndex<16; bitIndex++) {
                i2c.write(BesI2cAddrType.PMU, 0xb7, "dynWrite_Efuse_"+bitIndex);//open function turn on
                i2c.write(BesI2cAddrType.PMU, 0xb7, "dynWrite_WriteTrigger_"+bitIndex);//write trigger enable
                i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0019);//write trigger disable
//                i2c.waitTime(0.5e6);
            }
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0009);//function turn off
            i2c.write(BesI2cAddrType.PMU, 0xb5, 0x0000);//clear data[14:10],address[9:4]
            i2c.write(BesI2cAddrType.PMU, 0xb7, 0x0000);                //close clock,pgm mode
        i2c.transactionSequenceEnd();
        measurement.setSetups(ds1);
    }

    @Override
    public void writeEfuse(int efuseAddr, MultiSiteLong efuseData, IMeasurement measurement, MultiSiteBoolean isEfuse) {
        MultiSiteLong dynWriteBitValue=new MultiSiteLong(0);
        MultiSiteLong dynWriteFlag=new MultiSiteLong(0);
        for(int bitIndex=0; bitIndex<16; bitIndex++) {
            for(int site:efuseData.getActiveSites()) {
                long bitValue=(efuseData.get(site) >> bitIndex) & 0x1;
                dynWriteBitValue.set(site,0);
                dynWriteFlag.set(site, 0);
                dynWriteBitValue.set(site, (((bitValue<<bitIndex) | (bitValue<<(bitIndex+16)))<<10) | (efuseAddr<<4) );
                if(bitValue==1 & isEfuse.get(site)) {
                    dynWriteFlag.set(site, 0x0038);
                }
                else {
                    dynWriteFlag.set(site, 0x0018);
                }
            }
            ProtocolAccess.setDynamicData("dynWrite_Efuse_"+bitIndex, dynWriteBitValue);
            ProtocolAccess.setDynamicData("dynWrite_WriteTrigger_"+bitIndex, dynWriteFlag);
        }
        measurement.execute();
    }




}
